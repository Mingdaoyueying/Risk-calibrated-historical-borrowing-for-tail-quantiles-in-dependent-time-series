#!/usr/bin/env python3
"""Diagnostic figures from all retained financial and simulation results, 300 dpi."""
from pathlib import Path
import json,io,os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm,LinearSegmentedColormap
import matplotlib.dates as mdates
from matplotlib.font_manager import fontManager

ROOT=Path(__file__).resolve().parents[1]
COLS=['NoDur','Durbl','Manuf','Enrgy','Chems','BusEq','Telcm','Utils','Shops','Hlth','Money','Other']
NATURE=['#3C5488','#00A087','#E64B35','#4DBBD5','#F39B7F','#8491B4','#91D1C2']
AVAILABLE_FONTS={font.name for font in fontManager.ttflist}
FONT=next((name for name in ('Times New Roman','Nimbus Roman','Liberation Serif','DejaVu Serif') if name in AVAILABLE_FONTS),'serif')
CAPTIONS={
 'F1_Financial_Loss_Comparison':'Financial pinball-loss ratios against Recent for all 12 industries and both quantile levels.',
 'F2_Borrowing_Increment':'Paired financial borrowing gains relative to identical recent-window selection.',
 'F3_Weights_Windows_and_Forecasts':'Financial quantile forecasts, selected windows, borrowing weights, and diagnostic distributions.',
 'F4_Coverage':'Financial tail-hit frequencies and coverage diagnostics across all industries.',
 'F5_Financial_Robustness':'Main and sensitivity financial designs, with all industry comparisons retained.',
 'F6_Simulation_Total_Gain':'Total simulation estimation gains relative to the full recent-window estimator.',
 'F7_Simulation_Borrowing_Increment':'Incremental simulation borrowing gains relative to the identical recent-window selector.',
 'F8_Simulation_Method_Tradeoffs':'Method comparisons within the predefined simulation scenario groups.',
 'F9_Independent_Precision_Audit':'All seven flagged data-generating configurations, each independently reassessed with 10,000 replications at both quantile levels; pointwise Monte Carlo intervals and the 1.05 reference are shown.'}
plt.rcParams.update({'font.family':FONT,'font.weight':'bold','axes.labelweight':'bold','axes.titleweight':'bold',
 'font.size':11,'axes.linewidth':1.3,'lines.linewidth':1.8,'xtick.major.width':1.2,'ytick.major.width':1.2,
 'savefig.dpi':300,'figure.dpi':120,'axes.spines.top':False,'axes.spines.right':False})
CMAP=LinearSegmentedColormap.from_list('nature_diverging',[NATURE[2],'#FFFFFF',NATURE[1]])
LABELS={'recent':'Recent','pooled':'Pool','fixed_bias_borrow':'Fixed borrow','score_only_01':'Select only',
 'score_borrow_01':'Select + borrow','cv_window':'CV','cv_one_se':'CV (1-SE)','ewma_normal':'Normal',
 'short_recent':'Short','lepski_only':'Lepski','score_only_10':'Select (10%)','score_borrow_10':'Borrow (10%)',
 'no_borrow_after_shortening':'Borrow gate','plugin':'Plugin','risk_original':'Original risk'}
SCENARIOS=['stable','stable_t5','location_down','location_up','scale_up','scale_down','tail_shape',
 'break25','break50','break75','gradual_scale','location_break50','recur_scale50','recur_scale25','recur_location50','recur_tail50']
SLABELS=['Stable normal','Stable t(5)','Location down','Location up','Scale up','Scale down','Tail shift',
 'Break, last 25%','Break, last 50%','Break, last 75%','Gradual scale','Location break','Scale recurrence (50%)',
 'Scale recurrence (25%)','Location recurrence','Tail recurrence']
PRIMARY=['pooled','fixed_bias_borrow','score_only_01','score_borrow_01','cv_window','cv_one_se','ewma_normal']
FIGURES=[]

def save(fig,name,caption):
    caption=CAPTIONS.get(name,caption)
    from PIL import Image
    buffer=io.BytesIO();fig.savefig(buffer,format='png',dpi=300,bbox_inches='tight',facecolor='white');plt.close(fig)
    raw=buffer.getvalue()
    with Image.open(io.BytesIO(raw)) as check:check.verify()
    path=ROOT/'figures'/f'{name}.png';temporary=ROOT/'figures'/f'.{name}.tmp.png'
    temporary.write_bytes(raw);os.replace(temporary,path)
    with Image.open(path) as check:check.verify()
    FIGURES.append({'name':name,'file':f'figures/{name}.png','caption':caption})

def heatmap(ax,data,rows,cols,title,extent):
    ax.spines['left'].set_visible(False);ax.spines['bottom'].set_visible(False)
    lim=max(extent,1e-6);im=ax.imshow(data,cmap=CMAP,norm=TwoSlopeNorm(vmin=-lim,vcenter=0,vmax=lim),aspect='auto')
    ax.set_xticks(np.arange(len(cols)),cols,rotation=30,ha='right');ax.set_yticks(np.arange(len(rows)),rows)
    ax.tick_params(length=0);ax.set_title(title,pad=12)
    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            ax.text(j,i,f'{data[i,j]:.2f}',ha='center',va='center',fontsize=8.5,
                    color='white' if abs(data[i,j])>lim*.60 else '#172D3B')
    return im

def financial_figures():
    s=pd.read_csv(ROOT/'tables/financial_summary.csv');ab=pd.read_csv(ROOT/'tables/financial_ablation.csv')
    w=pd.read_csv(ROOT/'tables/financial_windows_weights.csv');main=s[s.config=='main']
    matrices=[main[main.tau==t].pivot(index='industry',columns='method',values='reduction_percent').reindex(index=COLS,columns=PRIMARY).to_numpy() for t in (.01,.05)]
    limit=max(float(np.abs(m).max()) for m in matrices)
    fig,axes=plt.subplots(1,2,figsize=(14,6));fig.subplots_adjust(wspace=.30,bottom=.20,right=.90)
    im=None
    for ax,tau,matrix,letter in zip(axes,(.01,.05),matrices,'ab'):
        im=heatmap(ax,matrix,COLS,[LABELS[m] for m in PRIMARY],f'({letter}) Quantile {tau:.0%}',limit)
    cax=fig.add_axes([.92,.22,.018,.61]);cb=fig.colorbar(im,cax=cax);cb.set_label('Pinball loss reduction vs. recent (%)')
    save(fig,'F1_Financial_Loss_Comparison','主方案7个非近期基准方法的相对分位数损失改善。数值为100×(1−损失比)，正值表示改善；所有12行业及两个分位水平完整保留。')
    fig,axes=plt.subplots(1,2,figsize=(12,6.5),sharey=True)
    for ax,tau,letter,color in zip(axes,(.01,.05),'ab',NATURE[:2]):
        d=ab[(ab.config=='main')&(ab.tau==tau)&(ab.candidate=='score_borrow_01')&(ab.reference=='score_only_01')].set_index('industry').reindex(COLS)
        y=np.arange(len(COLS));ax.axvline(0,color='#333333',ls='--',lw=1.2)
        for i,(_,row) in enumerate(d.iterrows()):
            sig=row.dm_bh_p<.05;ax.errorbar(row.reduction_percent,i,xerr=196*row.ratio_hac_se,fmt='o',color=color,
                markerfacecolor=color if sig else 'white',markersize=6,capsize=3,elinewidth=1.5)
        ax.set_yticks(y,COLS);ax.set_ylim(len(COLS)-.5,-.5);ax.set_title(f'({letter}) Quantile {tau:.0%}');ax.set_xlabel('Borrowing increment in pinball loss (%)');ax.grid(axis='x',alpha=.18)
    fig.tight_layout()
    save(fig,'F2_Borrowing_Increment','与相同选窗但不借用的估计比较。误差线为配对损失比的逐点95% HAC Delta区间；实心点表示192个消融检验家族中的BH调整p<0.05。区间未作同时覆盖修正。')
    cache={}
    for col in COLS:
        with np.load(ROOT/'results/financial/main'/f'{col}.npz') as x:
            cache[col]={k:x[k] for k in ('dates','selected_weight','actual_return_percent','forecasts','methods','selected_n','selected_n10')}
    dates=pd.to_datetime(cache[COLS[0]]['dates']);allweights=np.stack([cache[c]['selected_weight'] for c in COLS])
    fig,axes=plt.subplots(2,2,figsize=(13.5,8.5));a,b,c,d=axes.ravel()
    for ti,tau,color in zip(range(2),(.01,.05),NATURE[:2]):
        rolling=np.stack([pd.Series(allweights[i,:,ti]).rolling(126,min_periods=20).mean().to_numpy() for i in range(12)])
        valid=np.isfinite(rolling).all(axis=0)
        a.plot(dates[valid],np.mean(rolling[:,valid],axis=0),color=color,label=f'{tau:.0%} quantile')
        a.fill_between(dates[valid],np.quantile(rolling[:,valid],.1,axis=0),np.quantile(rolling[:,valid],.9,axis=0),color=color,alpha=.13)
        sortedw=np.sort(allweights[:,:,ti].ravel());c.plot(sortedw,np.arange(1,len(sortedw)+1)/len(sortedw),color=color,label=f'{tau:.0%} quantile')
    a.set_title('(a) 126-day mean borrowing weight');a.set_ylabel('Weight');a.legend(frameon=False,fontsize=10);a.xaxis.set_major_locator(mdates.YearLocator(2))
    a.set_xlim(dates[0],dates[-1])
    dwin=w[(w.config=='main')&(w.tau==.01)].set_index('industry').reindex(COLS)
    y=np.arange(12)
    for offset,col,color,label in [(-.14,'shrink_fraction_01',NATURE[0],'1% selector'),(.14,'shrink_fraction_10',NATURE[2],'10% selector')]:
        value=100*dwin[col].to_numpy();b.hlines(y+offset,0,value,color=color,alpha=.55);b.plot(value,y+offset,'o',color=color,ms=4.5,label=label)
    b.set_yticks(y,COLS);b.invert_yaxis();b.set_xlabel('Shorter-window frequency (%)');b.set_title('(b) Actual window shortening');b.legend(frameon=False,fontsize=9,loc='lower right')
    c.set_title('(c) Borrowing-weight distribution');c.set_xlabel('Weight');c.set_ylabel('Empirical CDF');c.legend(frameon=False,fontsize=10)
    x=cache['Enrgy'];m=list(x['methods']);d.plot(dates,x['actual_return_percent'],color='#8A969F',lw=.6,alpha=.45,label='Return')
    d.plot(dates,x['forecasts'][:,0,m.index('score_borrow_01')],color=NATURE[0],lw=1,label='1% quantile')
    d.plot(dates,x['forecasts'][:,1,m.index('score_borrow_01')],color=NATURE[1],lw=1,label='5% quantile')
    d.set_title('(d) Energy industry, full test period');d.set_ylabel('Return / lower quantile (%)');d.xaxis.set_major_locator(mdates.YearLocator(2));d.legend(frameon=False,ncol=3,fontsize=9)
    d.set_xlim(dates[0],dates[-1])
    fig.tight_layout()
    save(fig,'F3_Weights_Windows_and_Forecasts','(a)12行业借用权重的126日滚动均值及行业10%—90%范围；该阴影不是置信区间。(b)1%与10%选窗实际缩窗比例。(c)全部借用权重经验分布。(d)能源行业完整2015—2025年收益与下尾分位预测。')
    fig,axes=plt.subplots(1,2,figsize=(13.5,4.9),sharex=True)
    covmethods=['recent','score_borrow_01','pooled','cv_one_se','ewma_normal']
    for ax,tau,letter in zip(axes,(.01,.05),'ab'):
        ax.axhline(100*tau,color='#333333',ls='--',lw=1.5)
        for j,method in enumerate(covmethods):
            value=100*main[(main.tau==tau)&(main.method==method)].set_index('industry').reindex(COLS).hit_rate
            ax.plot(np.arange(12)+(j-2)*.11,value,marker='o',ls='none',ms=5,color=NATURE[j],label=LABELS[method])
        ax.set_xticks(np.arange(12),COLS,rotation=45,ha='right');ax.set_ylabel('Observed tail-hit rate (%)');ax.set_title(f'({letter}) Nominal {tau:.0%}');ax.grid(axis='y',alpha=.18)
    handles,labels=axes[0].get_legend_handles_labels();fig.legend(handles,labels,ncol=5,loc='upper center',bbox_to_anchor=(.5,1.02),frameon=False)
    fig.tight_layout(rect=[0,0,1,.94]);save(fig,'F4_Coverage','各行业实际违约频率；虚线为目标尾部概率。UC、独立性、条件覆盖LR统计量与调整前后p值全部见表，违约率接近目标不等于独立性成立。')
    cids=['main','recent750','block5','block20','risk025','risk100','gap60','ewma097','seed_repeat']
    clabels=['Main','n=750','Block=5','Block=20','Budget=2.5%','Budget=10%','Gap=60','EWMA=.97','Seed 2']
    fig,axes=plt.subplots(1,2,figsize=(14,5.5))
    for ax,tau,letter in zip(axes,(.01,.05),'ab'):
        ax.axhline(0,color='#333333',ls='--',lw=1.2)
        for offset,ref,color,label in [(-.10,'recent',NATURE[0],'vs. recent'),(.10,'score_only_01',NATURE[1],'vs. same selection')]:
            for i,cid in enumerate(cids):
                v=ab[(ab.config==cid)&(ab.tau==tau)&(ab.candidate=='score_borrow_01')&(ab.reference==ref)].reduction_percent.to_numpy()
                ax.vlines(i+offset,v.min(),v.max(),color=color,lw=1.4,alpha=.7);ax.plot(i+offset,v.mean(),'o',color=color,ms=6,label=label if i==0 else None)
        ax.set_xticks(np.arange(len(cids)),clabels,rotation=35,ha='right');ax.set_ylabel('Pinball loss reduction (%)');ax.set_title(f'({letter}) Quantile {tau:.0%}');ax.legend(frameon=False,fontsize=10);ax.grid(axis='y',alpha=.18)
    fig.tight_layout();save(fig,'F5_Financial_Robustness','九个预先固定的金融设置。圆点为12行业相对改善的均值，竖线为行业最小—最大范围，不是置信区间；同时展示相对固定近期基准和相同选窗基准的结果。')

def simulation_figures():
    s=pd.read_csv(ROOT/'tables/simulation_summary.csv');ab=pd.read_csv(ROOT/'tables/simulation_ablation.csv')
    columns=[(.2,250),(.2,750),(.6,250),(.6,750)];labels=['phi=.2, n=250','phi=.2, n=750','phi=.6, n=250','phi=.6, n=750']
    for source,name,caption,titlecol in [(s[(s.family=='core1000')&(s.method=='score_borrow_01')].assign(gain=lambda d:100*(1-d.relative_mse)),'F6_Simulation_Total_Gain','新增64个基础配置，每格1,000次；共128个分位数配置，全部保留。展示两层方法相对固定近期基准的MSE改善。','gain'),
       (ab[ab.family=='core1000'],'F7_Simulation_Borrowing_Increment','同一组基础仿真中，比较两层方法与相同选窗但不借用历史的MSE。正值表示借用有独立增益；持续新状态与历史状态重现分开展示。','reduction_percent')]:
        matrices=[]
        for tau in (.01,.05):
            matrix=np.empty((16,4))
            for i,sc in enumerate(SCENARIOS):
                for j,(phi,n) in enumerate(columns):
                    subset=source[(source.tau==tau)&(source.scenario==sc)&(source.phi==phi)&(source.n_recent==n)]
                    assert len(subset)==1;matrix[i,j]=subset.iloc[0][titlecol]
            matrices.append(matrix)
        limit=max(float(np.abs(m).max()) for m in matrices)
        fig,axes=plt.subplots(1,2,figsize=(13.7,8));fig.subplots_adjust(wspace=.40,bottom=.18,right=.90)
        for ax,tau,matrix,letter in zip(axes,(.01,.05),matrices,'ab'):im=heatmap(ax,matrix,SLABELS,labels,f'({letter}) Quantile {tau:.0%}',limit)
        cax=fig.add_axes([.92,.22,.018,.60]);cb=fig.colorbar(im,cax=cax);cb.set_label('MSE reduction (%)')
        save(fig,name,caption)
    core=s[s.family=='core1000'].copy()
    core['group']=core.scenario.map(lambda sc:'Recurrence' if sc.startswith('recur_') else ('New state in recent' if sc in ['break25','break50','break75','gradual_scale','location_break50'] else 'Uniform recent'))
    methods=['pooled','fixed_bias_borrow','short_recent','lepski_only','score_only_10','score_borrow_10','score_only_01','score_borrow_01','no_borrow_after_shortening','cv_window','cv_one_se']
    fig,axes=plt.subplots(1,2,figsize=(13,7),sharey=True)
    for ax,tau,letter in zip(axes,(.01,.05),'ab'):
        for j,(group,color) in enumerate(zip(['Uniform recent','New state in recent','Recurrence'],NATURE[:3])):
            d=core[(core.tau==tau)&(core.group==group)].groupby('method').relative_mse.median().reindex(methods)
            ax.plot(d,np.arange(len(methods))+(j-1)*.15,'o',color=color,ms=5.5,label=group)
        ax.axvline(1,color='#333333',ls='--',lw=1.3);ax.set_yticks(np.arange(len(methods)),[LABELS[m] for m in methods]);ax.set_ylim(len(methods)-.5,-.5);ax.set_xlabel('Median relative MSE');ax.set_title(f'({letter}) Quantile {tau:.0%}');ax.grid(axis='x',alpha=.18)
    handles,labels=axes[0].get_legend_handles_labels();fig.legend(handles,labels,ncol=3,loc='upper center',bbox_to_anchor=(.5,1.02),frameon=False)
    fig.tight_layout(rect=[0,0,1,.94]);save(fig,'F8_Simulation_Method_Tradeoffs','三个预定义场景组中各比较方法的相对MSE中位数；参照线为固定近期基准1。每组完整的最小值、中位数、最大值、超预算计数和蒙特卡洛误差另见表。')

def precision_figure():
    path=ROOT/'tables/precision_simulation_summary.csv'
    if not path.exists():return
    precision=pd.read_csv(path);precision=precision[precision.method=='score_borrow_01']
    original=pd.read_csv(ROOT/'tables/simulation_summary.csv')
    cells=json.loads((ROOT/'docs/precision_manifest.json').read_text())['simulation']['cells']
    fig,axes=plt.subplots(1,2,figsize=(13,6),sharey=True)
    labels=[f"{SLABELS[SCENARIOS.index(c['scenario'])]} (phi={c['phi']:g}, n={c['n_recent']})" for c in cells]
    for ax,tau,letter in zip(axes,(.01,.05),'ab'):
        ax.axvline(1,color='#333333',ls='--',lw=1.1);ax.axvline(1.05,color=NATURE[2],ls=':',lw=1.5)
        for i,c in enumerate(cells):
            old=original[(original.family==c['source_family'])&(original.scenario==c['scenario'])&(original.phi==c['phi'])&(original.n_recent==c['n_recent'])&(original.tau==tau)&(original.method=='score_borrow_01')].iloc[0]
            new=precision[(precision.family==c['family'])&(precision.scenario==c['scenario'])&(precision.phi==c['phi'])&(precision.n_recent==c['n_recent'])&(precision.tau==tau)].iloc[0]
            for offset,row,color,label,face in [(-.10,old,'#909AA3','1,000 repetitions','white'),(.10,new,NATURE[0],'10,000 independent repetitions',NATURE[0])]:
                ax.errorbar(row.relative_mse,i+offset,xerr=1.96*row.ratio_mcse,fmt='o',color=color,markerfacecolor=face,
                    capsize=3,ms=5,label=label if i==0 else None)
        ax.set_yticks(np.arange(len(cells)),labels);ax.set_ylim(len(cells)-.5,-.5);ax.set_xlabel('Relative MSE vs. recent');ax.set_title(f'({letter}) Quantile {tau:.0%}');ax.grid(axis='x',alpha=.18)
    handles,labels=axes[0].get_legend_handles_labels();fig.legend(handles,labels,ncol=2,loc='upper center',bbox_to_anchor=(.5,1.02),frameon=False)
    fig.tight_layout(rect=[0,0,1,.94]);save(fig,'F9_Independent_Precision_Audit','对全部触发超预算条件的7个DGP配置，用独立种子各复核10,000次；每个配置两个分位数都保留。灰色为原1,000次，蓝色为精度复核，误差线为逐点95%蒙特卡洛Delta区间。红线为1.05；该组是结果触发的诊断性复核。')

def main():
    financial_figures();simulation_figures();precision_figure()
    (ROOT/'docs/figures_index.json').write_text(json.dumps(FIGURES,indent=2,ensure_ascii=False)+'\n')
    (ROOT/'docs/plot_font.json').write_text(json.dumps({'font':FONT,'weight':'bold','dpi':300,'palette':'Nature/NPG-style colors'},indent=2)+'\n')
    print('Created',len(FIGURES),'figures.')

if __name__=='__main__':main()
