#!/usr/bin/env python3
"""Recompute frozen examples and compare with the archived numerical outputs."""
from __future__ import annotations

import argparse
import copy
import importlib.metadata
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd

from financial_backtest import causal_filter
from financial_run import forecast_bundle
from prepare_data import prepare
from simulation_run import run_cell

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=ROOT / "reruns/smoke")
    source = parser.add_mutually_exclusive_group()
    source.add_argument("--input-zip", type=Path)
    source.add_argument("--download-raw", action="store_true")
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    data_check = prepare(out / "data/french12_value_weighted_2000_2025_percent.csv",
                         input_zip=args.input_zip, download_raw=args.download_raw)
    manifest = json.loads((ROOT / "docs/experiment_manifest.json").read_text())
    precision = json.loads((ROOT / "docs/precision_manifest.json").read_text())
    cases = ((manifest["simulation"], "core1000", "stable_t5", 250, 0.2),
             (manifest["simulation"], "core1000", "recur_scale50", 750, 0.6),
             (precision["simulation"], "precision_core1000", "break75", 250, 0.2))
    records = []
    for settings, family, scenario, n, phi in cases:
        cell = next(c for c in settings["cells"] if c["family"] == family
                    and c["scenario"] == scenario and c["n_recent"] == n
                    and c["phi"] == phi)
        cfg = copy.deepcopy(settings)
        cfg["reps"] = 3
        directory = out / "simulation" / family
        run_cell(cell, cfg, directory)
        stem = f"{scenario}_phi{phi:g}_n{n}.npz"
        largest = 0.0
        reference = ROOT / "results/simulation" / family / stem
        if not reference.is_file():
            reference = ROOT / "results/reference/simulation" / family / stem
        with np.load(directory / stem) as actual, np.load(reference) as expected:
            for key in actual.files:
                a, b = actual[key], expected[key]
                if key not in ("truth", "taus", "methods", "grid"):
                    b = b[:3]
                if a.dtype.kind in "f":
                    np.testing.assert_allclose(a, b, rtol=1e-12, atol=1e-12)
                    largest = max(largest, float(np.max(np.abs(a - b))))
                else:
                    np.testing.assert_array_equal(a, b)
        records.append({"family": family, "scenario": scenario,
                        "n_recent": n, "phi": phi, "replications": 3,
                        "max_absolute_difference": largest})

    frame = pd.read_csv(ROOT / "data/french12_value_weighted_2000_2025_percent.csv")
    finance_records = []
    cases = (("main", "Telcm", (0, 1000, 2765)),
             ("recent750", "Enrgy", (0, 2765)),
             ("risk025", "NoDur", (0, 2765)))
    for configuration, industry, positions in cases:
        cfg = next(c for c in manifest["financial_configs"] if c["id"] == configuration)
        series = frame[industry].to_numpy(float)
        sigma, residuals = causal_filter(series, cfg["ewma_decay"], cfg["burn"])
        industry_index = manifest["industries"].index(industry)
        reference = ROOT / "results/financial" / configuration / f"{industry}.npz"
        if not reference.is_file():
            reference = ROOT / "results/reference/financial" / configuration / f"{industry}.npz"
        with np.load(reference) as ref:
            for original_position in positions:
                position = (int(np.flatnonzero(ref["reference_position"] == original_position)[0])
                            if "reference_position" in ref.files else original_position)
                origin = int(ref["origin_index"][position])
                forecasts, diagnostics = forecast_bundle(
                    residuals[:origin], sigma[origin], cfg,
                    [cfg["seed"], industry_index, origin])
                np.testing.assert_allclose(forecasts, ref["forecasts"][position],
                                           rtol=1e-12, atol=1e-12)
                for key, value in diagnostics.items():
                    np.testing.assert_allclose(value, ref[key][position],
                                               rtol=1e-12, atol=1e-12)
                finance_records.append({"configuration": configuration,
                    "industry": industry, "date": str(ref["dates"][position]),
                    "origin_index": origin, "forecast_values": int(forecasts.size),
                    "max_absolute_difference": float(np.max(np.abs(
                        forecasts - ref["forecasts"][position])))})
    report = {"status": "PASS", "prepared_data": data_check,
              "simulation_checks": records, "financial_checks": finance_records,
              "simulation_replications_recomputed": 9,
              "financial_origins_recomputed": 7,
              "financial_forecast_values_recomputed": 210,
              "bootstrap_draws": 199, "selector_multiplier_draws": 999,
              "tolerance": {"rtol": 1e-12, "atol": 1e-12},
              "environment": {"python": sys.version.split()[0],
                **{name: importlib.metadata.version(name) for name in
                   ("numpy", "scipy", "pandas", "matplotlib", "Pillow")}}}
    (out / "smoke_validation.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
