#!/usr/bin/env python3
"""Regenerate the complete scenario-group and sensitivity-family summaries."""
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
GROUPS = ["Historical recurrence",
          "Homogeneous recent window (including historical mismatch)",
          "Persistent new state within the recent window"]
NEW_STATES = {"break25", "break50", "break75", "gradual_scale", "location_break50"}


def main() -> None:
    simulation = pd.read_csv(ROOT / "tables/simulation_summary.csv")
    selected = simulation[simulation.method == "score_borrow_01"]
    core = selected[selected.family == "core1000"].copy()
    core["group"] = core.scenario.map(lambda scenario: GROUPS[0]
        if scenario.startswith("recur_") else
        GROUPS[2] if scenario in NEW_STATES else GROUPS[1])
    core["group"] = pd.Categorical(core["group"], categories=GROUPS, ordered=True)
    grouped = core.groupby(["group", "tau"], observed=True).agg(
        cells=("relative_mse", "size"), minimum=("relative_mse", "min"),
        median=("relative_mse", "median"), maximum=("relative_mse", "max"),
        over105=("point_exceeds_risk_budget", "sum")).reset_index()
    families = selected.groupby("family").agg(
        quantile_cells=("relative_mse", "size"), min_ratio=("relative_mse", "min"),
        median_ratio=("relative_mse", "median"), max_ratio=("relative_mse", "max"),
        over_budget=("point_exceeds_risk_budget", "sum")).reset_index()
    grouped.to_csv(ROOT / "tables/simulation_group_overview.csv", index=False)
    families.to_csv(ROOT / "tables/simulation_sensitivity_overview.csv", index=False)
    print("Generated scenario-group and sensitivity-family overview tables.")


if __name__ == "__main__":
    main()
