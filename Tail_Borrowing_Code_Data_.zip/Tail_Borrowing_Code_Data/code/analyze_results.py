#!/usr/bin/env python3
"""Summarize every retained forecast and Monte Carlo cell without filtering results."""
from __future__ import annotations
import argparse,csv,gzip,json,math
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.special import xlogy
from scipy.stats import chi2,norm
from financial_backtest import hac_mean_se,bh_adjust

ROOT=Path(__file__).resolve().parents[1]

def coverage(hit,tau):
    h=np.asarray(hit,dtype=int);N=len(h);K=int(h.sum());p=K/N
    ll0=xlogy(K,tau)+xlogy(N-K,1-tau);ll1=xlogy(K,p)+xlogy(N-K,1-p)
    uc=max(float(2*(ll1-ll0)),0.)
    a,b=h[:-1],h[1:];counts=np.bincount(2*a+b,minlength=4).reshape(2,2);n00,n01,n10,n11=counts.ravel()
    if counts.sum(axis=1).min()==0:
        ind=indp=cc=ccp=float('nan')
    else:
        p01=n01/(n00+n01);p11=n11/(n10+n11);pi=(n01+n11)/counts.sum()
        lind=xlogy(n01+n11,pi)+xlogy(n00+n10,1-pi)
        lmark=xlogy(n01,p01)+xlogy(n00,1-p01)+xlogy(n11,p11)+xlogy(n10,1-p11)
        ind=max(float(2*(lmark-lind)),0.);indp=float(chi2.sf(ind,1));cc=uc+ind;ccp=float(chi2.sf(cc,2))
    return {'n':N,'violations':K,'hit_rate':p,'uc_lr':uc,'uc_p':float(chi2.sf(uc,1)),
       'ind_lr':ind,'ind_p':indp,'cc_lr':cc,'cc_p':ccp,'n00':int(n00),'n01':int(n01),'n10':int(n10),'n11':int(n11)}

def ratio_stats(loss,base,lag=10):
    loss=np.asarray(loss);base=np.asarray(base);R=float(loss.mean()/base.mean())
    se=hac_mean_se(loss-R*base,lag)/float(base.mean())
    return R,se,max(0.,R-1.96*se),R+1.96*se

def loss_comparison(loss,base,lag=10):
    d=np.asarray(loss)-np.asarray(base);md=float(d.mean());se=hac_mean_se(d,lag)
    z=md/se if se>0 else 0.;p=float(2*norm.sf(abs(z))) if se>0 else 1.
    R,rse,lo,hi=ratio_stats(loss,base,lag)
    return {'loss_difference':md,'hac_se':se,'hac_z':z,'dm_p':p,'diff_ci_low':md-1.96*se,'diff_ci_high':md+1.96*se,
            'loss_ratio':R,'ratio_hac_se':rse,'ratio_ci_low':lo,'ratio_ci_high':hi,'reduction_percent':100*(1-R)}

def paired_block_ci(loss,base,rng,B=1999,L=20):
    """Circular block bootstrap of the fixed paired loss series, no model refit."""
    loss=np.asarray(loss);base=np.asarray(base);N=len(loss);blocks,rem=divmod(N,L)
    starts=rng.integers(0,N,size=(B,blocks+(rem>0)))
    def totals(x):
        prefix=np.r_[0.,np.cumsum(np.r_[x,x[:L-1]])]
        rolling=prefix[L:]-prefix[:-L]
        total=rolling[starts[:,:blocks]].sum(axis=1)
        if rem:
            part=prefix[rem:]-prefix[:-rem];total+=part[starts[:,-1]]
        return total
    sl,sb=totals(loss),totals(base);rb=sl/sb;R=float(loss.mean()/base.mean())
    centered=rb-R;qlo,qhi=np.quantile(centered,[.025,.975])
    dp=(sl-sb)/N;observed=float((loss-base).mean());centered_d=dp-observed
    return {'block_ratio_ci_low':float(R-qhi),'block_ratio_ci_high':float(R-qlo),
      'block_two_sided_p':float((1+np.sum(np.abs(centered_d)>=abs(observed)))/(B+1)),
      'loss_block_length':L,'loss_bootstrap_reps':B}

PAIRS=(('score_borrow_01','recent'),('score_borrow_01','score_only_01'),('score_borrow_01','fixed_bias_borrow'),
       ('score_only_01','recent'),('fixed_bias_borrow','recent'),('score_borrow_01','cv_one_se'),
       ('score_borrow_01','pooled'),('fixed_bias_borrow','risk_original'))

def financial(config_ids=None):
    manifest=json.loads((ROOT/'docs/experiment_manifest.json').read_text());rows=[];ablations=[];windows=[];annual=[]
    primary=manifest['primary_financial_methods'];aggregate_series={}
    for ci,cfg in enumerate(manifest['financial_configs']):
        if config_ids and cfg['id'] not in config_ids:continue
        for si,col in enumerate(manifest['industries']):
            path=ROOT/'results/financial'/cfg['id']/f'{col}.npz'
            if not path.exists():raise FileNotFoundError(path)
            with np.load(path) as x:
                methods=list(x['methods']);loss=x['pinball_loss'];actual=x['actual_return_percent'];hits=x['hits'];dates=x['dates']
                assert np.isfinite(x['forecasts']).all() and len(dates)==2766 and len(np.unique(dates))==2766
                assert np.all((x['selected_weight']>=0)&(x['selected_weight']<=1))
                assert np.all(np.abs(x['forecasts'][:,:,4]-x['forecasts'][:,:,3])<=x['selected_radius_percent']+1e-10)
                years=np.array([int(s[:4]) for s in dates])
                for ti,tau in enumerate(x['taus']):
                    base=loss[:,ti,0]
                    for mi,method in enumerate(methods):
                        ls=loss[:,ti,mi];cmp=loss_comparison(ls,base)
                        row={'config':cfg['id'],'industry':col,'tau':float(tau),'method':method,'original_primary_method':method in primary,
                             'mean_pinball_loss':float(ls.mean()),**cmp,**coverage(hits[:,ti,mi],float(tau)),
                             'crossing_count':int(x['crossings'][:,mi].sum())}
                        for lag in (5,20):row[f'dm_p_hac{lag}']=loss_comparison(ls,base,lag)['dm_p']
                        rows.append(row)
                        aggregate_series.setdefault((cfg['id'],float(tau),method),[]).append(ls)
                        if cfg['id']=='main':
                            for year in np.unique(years):
                                mask=years==year;R=float(ls[mask].mean()/base[mask].mean())
                                annual.append({'industry':col,'tau':float(tau),'method':method,'year':int(year),'n':int(mask.sum()),'mean_pinball_loss':float(ls[mask].mean()),'loss_ratio_vs_recent':R,'hit_rate':float(hits[mask,ti,mi].mean())})
                    for pi,(candidate,reference) in enumerate(PAIRS):
                        ls=loss[:,ti,methods.index(candidate)];bs=loss[:,ti,methods.index(reference)]
                        out={'config':cfg['id'],'industry':col,'tau':float(tau),'candidate':candidate,'reference':reference,**loss_comparison(ls,bs)}
                        if cfg['id']=='main' and reference in ('recent','score_only_01') and candidate=='score_borrow_01':
                            out.update(paired_block_ci(ls,bs,np.random.default_rng(np.random.SeedSequence([2026101214,si,ti,pi]))))
                        ablations.append(out)
                    w=x['selected_weight'][:,ti];la=x['selected_lambda'][:,ti]
                    windows.append({'config':cfg['id'],'industry':col,'tau':float(tau),'n':len(w),'recent_n':cfg['n_recent'],
                        'mean_selected_n':float(x['selected_n'].mean()),'shrink_fraction_01':float(np.mean(x['selected_n']<cfg['n_recent'])),
                        'shrink_fraction_10':float(np.mean(x['selected_n10']<cfg['n_recent'])),'mean_weight':float(w.mean()),
                        'median_weight':float(np.median(w)),'p05_weight':float(np.quantile(w,.05)),'p95_weight':float(np.quantile(w,.95)),
                        'mean_lambda':float(la.mean()),'median_lambda':float(np.median(la)),
                        'mean_cv_n':float(x['cv_n'][:,ti].mean()),'mean_cv_one_se_n':float(x['cv_one_se_n'][:,ti].mean())})
    df=pd.DataFrame(rows);ab=pd.DataFrame(ablations)
    for cid in df.config.unique():
        mask=(df.config==cid)&(df.method!='recent');df.loc[mask,'dm_bh_p']=bh_adjust(df.loc[mask,'dm_p'])
        original=(df.config==cid)&df.original_primary_method&(df.method!='recent')
        df.loc[original,'dm_bh_p_original8']=bh_adjust(df.loc[original,'dm_p'])
        for field in ('uc_p','ind_p','cc_p'):
            valid=(df.config==cid)&df[field].notna();df.loc[valid,field.replace('_p','_bh_p')]=bh_adjust(df.loc[valid,field])
        mask=ab.config==cid;ab.loc[mask,'dm_bh_p']=bh_adjust(ab.loc[mask,'dm_p'])
    aggregates=[]
    for (cid,tau,method),series in aggregate_series.items():
        same=df[(df.config==cid)&(df.tau==tau)&(df.method==method)]
        average_daily=np.mean(series,axis=0);base_daily=np.mean(aggregate_series[(cid,tau,'recent')],axis=0)
        aggregates.append({'config':cid,'tau':tau,'method':method,'industry_cells':len(series),
            'mean_industry_loss_ratio':float(same.loss_ratio.mean()),'median_industry_loss_ratio':float(same.loss_ratio.median()),
            'min_industry_loss_ratio':float(same.loss_ratio.min()),'max_industry_loss_ratio':float(same.loss_ratio.max()),
            'improved_industries':int((same.loss_ratio<1).sum()),'bh_significant_improved':int(((same.loss_difference<0)&(same.dm_bh_p<.05)).sum()),
            'mean_hit_rate':float(same.hit_rate.mean()),'uc_nonrejection_count':int((same.uc_p>=.05).sum()),
            'cc_nonrejection_count':int((same.cc_p>=.05).sum()),'crossing_count':int(same.crossing_count.sum()),
            'equal_industry_daily_mean_loss':float(average_daily.mean()),
            'aggregate_loss_ratio_vs_recent':float(average_daily.mean()/base_daily.mean()),
            'aggregate_daily_paired_dm_p':loss_comparison(average_daily,base_daily)['dm_p']})
    for name,frame in [('financial_summary',df),('financial_ablation',ab),('financial_aggregate',pd.DataFrame(aggregates)),
        ('financial_windows_weights',pd.DataFrame(windows)),('financial_by_year',pd.DataFrame(annual))]:
        frame.to_csv(ROOT/'tables'/f'{name}.csv',index=False)
    df[(df.config=='main')&df.original_primary_method].to_csv(ROOT/'tables/financial_primary_summary.csv',index=False)
    if not config_ids or 'main' in config_ids:export_main_predictions(manifest)
    return df,ab,pd.DataFrame(aggregates)

def export_main_predictions(manifest):
    target=ROOT/'results/financial/main_predictions.csv.gz';row_count=0
    with gzip.open(target,'wt',encoding='utf-8',newline='',compresslevel=6) as file:
        writer=csv.writer(file);writer.writerow(['date','industry','tau','method','actual_return_percent','forecast_quantile_percent','pinball_loss','hit','score_selected_n','borrowing_weight','crossing'])
        for col in manifest['industries']:
            with np.load(ROOT/'results/financial/main'/f'{col}.npz') as source:
                x={key:source[key] for key in ('dates','taus','methods','selected_weight','selected_n','fixed_weight','plugin_weight','original_weight','actual_return_percent','forecasts','pinball_loss','hits','crossings')}
                for i,date in enumerate(x['dates']):
                    for ti,tau in enumerate(x['taus']):
                        for mi,method in enumerate(x['methods']):
                            w=''
                            if method in ('score_borrow_01','no_borrow_after_shortening'):w=float(x['selected_weight'][i,ti]) if method=='score_borrow_01' or x['selected_n'][i]==250 else 0.
                            elif method=='fixed_bias_borrow':w=float(x['fixed_weight'][i,ti])
                            elif method=='plugin':w=float(x['plugin_weight'][i,ti])
                            elif method=='risk_original':w=float(x['original_weight'][i,ti])
                            # 10% weights are not retained in the original V3 diagnostics; leave unavailable.
                            writer.writerow([date,col,float(tau),method,float(x['actual_return_percent'][i]),float(x['forecasts'][i,ti,mi]),float(x['pinball_loss'][i,ti,mi]),int(x['hits'][i,ti,mi]),int(x['selected_n'][i]),w,int(x['crossings'][i,mi])]);row_count+=1
    assert row_count==12*2766*2*15
    (ROOT/'docs/main_predictions_export.json').write_text(json.dumps({'file':str(target.relative_to(ROOT)),'rows':row_count,'forecast_units':'percent simple returns','blank_weight':'not applicable or unavailable; not zero','score_selected_n':'shared 1% score-selector diagnostic, not a method-specific sample length'},indent=2)+'\n')

def simulations(cfg=None,prefix='simulation'):
    if cfg is None:cfg=json.loads((ROOT/'docs/experiment_manifest.json').read_text())['simulation']
    rows=[];ab=[]
    for cell in cfg['cells']:
        stem=f"{cell['scenario']}_phi{cell['phi']:g}_n{cell['n_recent']}";p=ROOT/'results/simulation'/cell['family']/f'{stem}.npz'
        with np.load(p) as x:
            e=x['estimates']-x['truth'][None,:,None];sq=e*e;methods=list(x['methods']);R=len(e);mse=sq.mean(axis=0)
            assert R==cfg['reps'];assert np.isfinite(e).all()
            ia=methods.index('score_only_01');ib=methods.index('score_borrow_01')
            assert np.all(np.abs(x['estimates'][:,:,ib]-x['estimates'][:,:,ia])<=x['adjustment_radius']+1e-10)
            assert np.all(mse[:,ib]<=(np.sqrt(mse[:,ia])+np.sqrt(np.mean(x['adjustment_radius']**2,axis=0)))**2+1e-10)
            for ti,tau in enumerate(x['taus']):
                base=sq[:,ti,0];bm=float(base.mean())
                for mi,method in enumerate(methods):
                    ratio=float(mse[ti,mi]/bm);se=float(np.std(sq[:,ti,mi]-ratio*base,ddof=1)/math.sqrt(R)/bm)
                    rows.append({**cell,'tau':float(tau),'method':method,'reps':R,'mse':float(mse[ti,mi]),'bias':float(e[:,ti,mi].mean()),'relative_mse':ratio,'ratio_mcse':se,'ratio_ci_low':ratio-1.96*se,'ratio_ci_high':ratio+1.96*se,'risk_threshold':1+cell['risk_budget'],'point_exceeds_risk_budget':bool(ratio>1+cell['risk_budget'])})
                ref=sq[:,ti,ia];ratio=float(mse[ti,ib]/mse[ti,ia]);se=float(np.std(sq[:,ti,ib]-ratio*ref,ddof=1)/math.sqrt(R)/ref.mean())
                ab.append({**cell,'tau':float(tau),'reps':R,'mse_ratio_borrow_vs_selection':ratio,'reduction_percent':100*(1-ratio),'ratio_mcse':se,'ratio_ci_low':ratio-1.96*se,'ratio_ci_high':ratio+1.96*se,
                    'mean_selected_n':float(x['selected_n'].mean()),'shrink_fraction_01':float(np.mean(x['selected_n']<cell['n_recent'])),'mean_weight':float(x['adaptive_weight'][:,ti].mean())})
    df=pd.DataFrame(rows);ab=pd.DataFrame(ab)
    df.to_csv(ROOT/'tables'/f'{prefix}_summary.csv',index=False);ab.to_csv(ROOT/'tables'/f'{prefix}_ablation.csv',index=False)
    return df,ab

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--main-only',action='store_true');args=ap.parse_args()
    df,ab,ag=financial(['main'] if args.main_only else None)
    if not args.main_only:sim,simab=simulations()
    selected=df[(df.config=='main')&(df.method=='score_borrow_01')]
    absel=ab[(ab.config=='main')&(ab.candidate=='score_borrow_01')&(ab.reference=='score_only_01')]
    facts={'main_test_dates_per_industry':2766,'main_industries':12,'main_methods':15,'main_prediction_rows':12*2766*2*15,
      'two_layer_improved_cells':int((selected.loss_ratio<1).sum()),'two_layer_total_cells':24,
      'two_layer_bh_significantly_improved_cells':int(((selected.loss_difference<0)&(selected.dm_bh_p<.05)).sum()),
      'two_layer_bh_significantly_improved_original8':int(((selected.loss_difference<0)&(selected.dm_bh_p_original8<.05)).sum()),
      'two_layer_mean_reduction_percent':float(selected.reduction_percent.mean()),'two_layer_min_reduction_percent':float(selected.reduction_percent.min()),'two_layer_max_reduction_percent':float(selected.reduction_percent.max()),
      'borrowing_bh_significantly_improved_vs_selection':int(((absel.loss_difference<0)&(absel.dm_bh_p<.05)).sum()),
      'all_financial_designs_complete':not args.main_only}
    if not args.main_only:
        core=sim[(sim.family=='core1000')&(sim.method=='score_borrow_01')]
        facts.update({'new_simulation_paths':104000,'new_simulation_cells':104,'new_quantile_cells':208,'core_worst_relative_mse':float(core.relative_mse.max()),'core_exceeds_105_cells':int((core.relative_mse>1.05).sum()),'all_simulations_complete':True})
        precision_file=ROOT/'docs/precision_manifest.json'
        if precision_file.exists():
            precision_cfg=json.loads(precision_file.read_text())['simulation']
            ps,_=simulations(precision_cfg,'precision_simulation');p=ps[ps.method=='score_borrow_01']
            paths=len(precision_cfg['cells'])*precision_cfg['reps']
            facts.update({'precision_paths':paths,'precision_dgp_cells':len(precision_cfg['cells']),
                'total_new_simulation_paths':104000+paths,'precision_worst_relative_mse':float(p.relative_mse.max()),
                'precision_over105_points':int((p.relative_mse>1.05).sum()),'precision_ci_low_over105':int((p.ratio_ci_low>1.05).sum())})
    (ROOT/'docs/summary_facts.json').write_text(json.dumps(facts,indent=2)+'\n');print(json.dumps(facts,indent=2))

if __name__=='__main__':main()
