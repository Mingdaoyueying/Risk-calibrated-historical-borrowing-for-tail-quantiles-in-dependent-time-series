#!/usr/bin/env python3
from __future__ import annotations
import json,time,math,argparse
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
from scipy.stats import norm,t
from run_v3 import dgp,SCENARIOS
from adaptive import window_grid,lepski_select,borrowing
from adaptive_refined import score_select_two_levels,cv_with_one_se
from estimator import block_draws,quantile_from_sorted
ROOT=Path(__file__).resolve().parents[1]
SCENARIOS_B=SCENARIOS+('recur_scale50','recur_scale25','recur_location50','recur_tail50')
METHODS_B=('recent','pooled','fixed_bias_borrow','short_recent','lepski_only',
'score_only_10','score_borrow_10','score_only_01','score_borrow_01','no_borrow_after_shortening','cv_window','cv_one_se')

def dgp_b(n,phi,sc,rng,gap,taus):
    if not sc.startswith('recur_'):return dgp(n,phi,sc,rng,gap,taus)
    h,r,truth=dgp(n,phi,'stable',rng,gap,taus)
    m=n-int(math.ceil(n*(.25 if sc=='recur_scale25' else .5)))
    if sc in ('recur_scale50','recur_scale25'):r[:m]*=1.5
    elif sc=='recur_location50':r[:m]-=.5
    elif sc=='recur_tail50':r[:m]=t.ppf(np.clip(norm.cdf(r[:m]),1e-12,1-1e-12),5)*math.sqrt(3/5)
    return h,r,truth

def run_cell(c,cfg,out):
    n,p,sc=c['n_recent'],c['phi'],c['scenario'];taus=np.array(cfg['taus']);grid=window_grid(n);K=len(grid);T=len(taus);R=cfg['reps']
    pred=np.empty((R,T,len(METHODS_B)));qgrid=np.empty((R,K,T));selected=np.empty(R,int);selected10=np.empty(R,int)
    lepski=np.empty((R,T),int);cv_n=np.empty((R,T),int);cv1_n=np.empty((R,T),int)
    weights=np.empty((R,T));lam=np.empty((R,T));radii=np.empty((R,T));fixedw=np.empty((R,T))
    crit=np.empty(R);crit10=np.empty(R);stats=np.empty((R,K-1));started=time.perf_counter()
    for rep in range(R):
        ss=np.random.SeedSequence([cfg['seed'],n,int(round(p*1000)),SCENARIOS_B.index(sc),rep])
        streams=[np.random.default_rng(s) for s in ss.spawn(3+K)]
        h,r,truth=dgp_b(n,p,sc,streams[0],cfg['gap'],taus)
        idx,j10,d1,d10=score_select_two_levels(r,streams[1],cfg['selector_bootstrap_reps'],cfg['block_length'])
        bh=block_draws(h,taus,cfg['bootstrap_reps'],cfg['block_length'],streams[2])[0]
        qh=quantile_from_sorted(np.sort(h),taus);vh=bh.var(axis=0,ddof=1);qs=[];vs=[];means=[]
        for j,m in enumerate(grid):
            y=r[-int(m):];bs=block_draws(y,taus,cfg['bootstrap_reps'],cfg['block_length'],streams[3+j])[0]
            qs.append(quantile_from_sorted(np.sort(y),taus));vs.append(bs.var(axis=0,ddof=1));means.append(bs.mean(axis=0))
        qs,vs,means=map(np.asarray,(qs,vs,means));ix=[K-1,j10,idx]
        qb,bd=borrowing(qs[ix],qh[None,:],vs[ix],vh[None,:],means[ix],cfg['bootstrap_reps'],cfg['risk_budget'])
        lp=lepski_select(qs,vs,.1);cv,cn,cv1,cn1=cv_with_one_se(h,r,taus,cfg['cv_stride'])
        gate=qs[idx] if idx<K-1 else qb[2]
        outputs=[qs[-1],np.quantile(np.r_[h,r],taus),qb[0],qs[0],qs[lp,np.arange(T)],qs[j10],qb[1],qs[idx],qb[2],gate,cv,cv1]
        pred[rep]=np.stack(outputs,axis=-1);qgrid[rep]=qs;selected[rep]=grid[idx];selected10[rep]=grid[j10]
        lepski[rep]=grid[lp];cv_n[rep]=cn;cv1_n[rep]=cn1;weights[rep]=bd['weight'][2];lam[rep]=bd['lambda'][2];radii[rep]=bd['radius'][2];fixedw[rep]=bd['weight'][0]
        crit[rep]=d1['score_critical'];crit10[rep]=d10['score_critical'];stats[rep]=d1['score_parent_statistics']
    stem=f'{sc}_phi{p:g}_n{n}'
    np.savez_compressed(out/f'{stem}.npz',estimates=pred,truth=truth,taus=taus,methods=METHODS_B,quantile_grid=qgrid,grid=grid,
        selected_n=selected,selected_n10=selected10,lepski_n=lepski,cv_n=cv_n,cv_one_se_n=cv1_n,adaptive_weight=weights,
        adaptive_lambda=lam,adjustment_radius=radii,fixed_weight=fixedw,selector_critical=crit,selector_critical10=crit10,selector_parent_statistics=stats)
    sec=time.perf_counter()-started;(out/f'{stem}.json').write_text(json.dumps({'cell':c,'replications':R,'elapsed_seconds':sec},indent=2))
    return stem,sec

def main():
    a=argparse.ArgumentParser();a.add_argument('--workers',type=int,default=4);a=a.parse_args()
    cfg=json.loads((ROOT/'manifest_refined.json').read_text());out=ROOT/'results_refined';out.mkdir(exist_ok=True)
    with ProcessPoolExecutor(max_workers=a.workers) as ex:
        fs=[ex.submit(run_cell,c,cfg,out) for c in cfg['cells']]
        for f in as_completed(fs):s,sec=f.result();print(f'Completed {s}: {sec:.1f}s',flush=True)
if __name__=='__main__':main()
