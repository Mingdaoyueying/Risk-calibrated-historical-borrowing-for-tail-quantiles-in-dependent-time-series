#!/usr/bin/env python3
"""Independent 10000-replication precision audit of every flagged DGP case."""
import argparse,hashlib,json
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
from simulation_run import run_cell
ROOT=Path(__file__).resolve().parents[1]
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=8);a=ap.parse_args()
    cfg=json.loads((ROOT/'docs/precision_manifest.json').read_text())['simulation']
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'code').glob('*.py') if p.name in ['simulation_run.py','precision_run.py','adaptive.py','adaptive_refined.py','estimator.py','risk_calibration.py','run_v3.py','run_refined.py']}
    (ROOT/'docs/precision_pre_run_code_hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
    with ProcessPoolExecutor(max_workers=a.workers) as ex:
        futures=[ex.submit(run_cell,c,cfg,ROOT/'results/simulation'/c['family']) for c in cfg['cells']]
        for future in as_completed(futures):
            family,stem,elapsed=future.result();print(f'Completed {family}/{stem}: {elapsed:.1f}s',flush=True)
if __name__=='__main__':main()
