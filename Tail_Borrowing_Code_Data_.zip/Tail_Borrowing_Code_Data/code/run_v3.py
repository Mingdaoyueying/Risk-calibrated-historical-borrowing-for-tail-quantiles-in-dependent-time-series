#!/usr/bin/env python3
"""Frozen-design Monte Carlo for the two-layer prototype and adaptive comparators."""
from __future__ import annotations
import argparse,json,math,time,hashlib
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
from scipy.signal import lfilter
from scipy.stats import norm,t
from adaptive import window_grid,multiscale_select,lepski_select,borrowing,prequential_window
from estimator import block_draws,quantile_from_sorted
ROOT=Path(__file__).resolve().parents[1]
SCENARIOS=('stable','stable_t5','location_down','location_up','scale_up','scale_down','tail_shape',
           'break25','break50','break75','gradual_scale','location_break50')
METHODS=('recent','pooled','fixed_bias_borrow','short_recent','lepski_only',
         'score_adaptive_only','score_adaptive_borrow','cv_window')

def dgp(n,phi,scenario,rng,gap,taus):
    N=4*n+gap;eps=rng.standard_normal(N)*math.sqrt(1-phi*phi)
    eps[0]/=math.sqrt(1-phi*phi);z=lfilter([1.],[1.,-phi],eps)
    hist=z[:3*n].copy();r=z[-n:].copy();truth=norm.ppf(taus);scales=np.ones(n);locations=np.zeros(n)
    if scenario=='stable_t5':
        hist=t.ppf(np.clip(norm.cdf(hist),1e-12,1-1e-12),5)*math.sqrt(3/5)
        r=t.ppf(np.clip(norm.cdf(r),1e-12,1-1e-12),5)*math.sqrt(3/5)
        truth=t.ppf(taus,5)*math.sqrt(3/5)
    elif scenario=='tail_shape':
        r=t.ppf(np.clip(norm.cdf(r),1e-12,1-1e-12),5)*math.sqrt(3/5)
        truth=t.ppf(taus,5)*math.sqrt(3/5)
    elif scenario=='location_down':locations[:]=-.5
    elif scenario=='location_up':locations[:]=.5
    elif scenario=='scale_up':scales[:]=1.5
    elif scenario=='scale_down':scales[:]=.7
    elif scenario.startswith('break'):
        scales[-int(math.ceil(n*int(scenario[5:])/100)):]=1.5
    elif scenario=='gradual_scale':scales=np.linspace(1.,1.5,n)
    elif scenario=='location_break50':locations[-int(math.ceil(n/2)):]=-.5
    elif scenario!='stable':raise ValueError(scenario)
    r=r*scales+locations;truth=truth*scales[-1]+locations[-1]
    return hist,r,truth

def run_cell(cell,cfg,out):
    n,phi,sc=cell['n_recent'],cell['phi'],cell['scenario'];taus=np.array(cfg['taus']);K=len(window_grid(n));T=len(taus)
    R=cfg['reps'];pred=np.empty((R,T,len(METHODS)));truth=None
    qgrid=np.empty((R,K,T));selected=np.empty(R,int);lepski=np.empty((R,T),int);cv_n=np.empty((R,T),int)
    weight=np.empty((R,T));lambdas=np.empty((R,T));radius=np.empty((R,T));fixedw=np.empty((R,T))
    crit=np.empty(R);stats=np.empty((R,K-1));started=time.perf_counter()
    for rep in range(R):
        seed=np.random.SeedSequence([cfg['seed'],n,int(round(phi*1000)),SCENARIOS.index(sc),rep])
        streams=[np.random.default_rng(s) for s in seed.spawn(2+K+1)]
        hist,recent,truth=dgp(n,phi,sc,streams[0],cfg['gap'],taus)
        idx,sd=multiscale_select(recent,streams[1],B=cfg['selector_bootstrap_reps'],block=cfg['block_length'],alpha=cfg['selector_alpha'])
        grid=window_grid(n)
        bh=block_draws(hist,taus,cfg['bootstrap_reps'],cfg['block_length'],streams[2])[0]
        qh=quantile_from_sorted(np.sort(hist),taus);vh=bh.var(axis=0,ddof=1)
        qs=[];vs=[];means=[]
        for j,m in enumerate(grid):
            r=recent[-int(m):];bs=block_draws(r,taus,cfg['bootstrap_reps'],cfg['block_length'],streams[3+j])[0]
            qs.append(quantile_from_sorted(np.sort(r),taus));vs.append(bs.var(axis=0,ddof=1));means.append(bs.mean(axis=0))
        qs,vs,means=map(np.asarray,(qs,vs,means))
        # Vectorise the two calibrations, preserving exactly the V2 formula.
        borrow,details=borrowing(qs[[K-1,idx]],qh[None,:],vs[[K-1,idx]],vh[None,:],means[[K-1,idx]],cfg['bootstrap_reps'],cfg['risk_budget'])
        lp=lepski_select(qs,vs,cfg['selector_alpha'])
        cv,cn,_=prequential_window(hist,recent,taus,cfg['cv_stride'])
        outs=[qs[-1],np.quantile(np.r_[hist,recent],taus),borrow[0],qs[0],qs[lp,np.arange(T)],qs[idx],borrow[1],cv]
        pred[rep]=np.stack(outs,axis=-1);qgrid[rep]=qs
        selected[rep]=int(grid[idx]);lepski[rep]=grid[lp];cv_n[rep]=cn
        weight[rep]=details['weight'][1];lambdas[rep]=details['lambda'][1];radius[rep]=details['radius'][1];fixedw[rep]=details['weight'][0]
        crit[rep]=sd['score_critical'];stats[rep]=sd['score_parent_statistics']
    stem=f'{sc}_phi{phi:g}_n{n}'
    np.savez_compressed(out/f'{stem}.npz',estimates=pred,truth=truth,taus=taus,methods=METHODS,
        quantile_grid=qgrid,grid=window_grid(n),selected_n=selected,lepski_n=lepski,cv_n=cv_n,
        adaptive_weight=weight,adaptive_lambda=lambdas,adjustment_radius=radius,fixed_weight=fixedw,
        selector_critical=crit,selector_parent_statistics=stats)
    secs=time.perf_counter()-started
    (out/f'{stem}.json').write_text(json.dumps({'cell':cell,'seed_protocol':'SeedSequence([seed,n,round(1000*phi),scenario_index,rep]); independent spawned data/selector/bootstrap streams','replications':R,'elapsed_seconds':secs},indent=2))
    return stem,secs

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--manifest',default=str(ROOT/'manifest.json'));ap.add_argument('--out',default=str(ROOT/'results'));ap.add_argument('--workers',type=int,default=4);ap.add_argument('--skip-existing',action='store_true');a=ap.parse_args()
    cfg=json.loads(Path(a.manifest).read_text());out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    cells=cfg['cells']
    if a.skip_existing:cells=[c for c in cells if not (out/f"{c['scenario']}_phi{c['phi']:g}_n{c['n_recent']}.json").exists()]
    with ProcessPoolExecutor(max_workers=a.workers) as ex:
        fs=[ex.submit(run_cell,c,cfg,out) for c in cells]
        for f in as_completed(fs):name,sec=f.result();print(f'Completed {name}: {sec:.1f}s',flush=True)
if __name__=='__main__':main()
