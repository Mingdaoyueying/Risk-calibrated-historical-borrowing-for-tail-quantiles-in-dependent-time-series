#!/usr/bin/env python3
"""Strictly historical residual-quantile backtest. NOT run on financial data here.
Input: official parsed French12 daily simple returns, percentage units. Use the
included downloader first on a machine with access, or pass a verified local CSV.
No interpolation, random train/test split, or test-set tuning is performed.
"""
from __future__ import annotations
import argparse,json,math
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import norm,chi2
from scipy.special import xlogy
from adaptive import window_grid, borrowing
from adaptive_refined import score_select_two_levels,cv_with_one_se
from estimator import block_draws,quantile_from_sorted

METHODS=('recent','pooled','fixed_bias_borrow','score_only_01','score_borrow_01','cv_window','cv_one_se','ewma_normal')

def causal_filter(returns,decay=.94,burn=250):
    """sigma[t] is known strictly before observing returns[t]. Mean fixed at zero.
    First burn observations initialize variance; their residuals are not used.
    """
    r=np.asarray(returns,float)
    if len(r)<=burn or not np.isfinite(r).all():raise ValueError('Require finite returns and sufficient warmup.')
    sigma=np.full(len(r),np.nan);z=np.full(len(r),np.nan)
    var=max(float(np.mean(r[:burn]**2)),1e-12)
    for t in range(burn,len(r)):
        sigma[t]=math.sqrt(var);z[t]=r[t]/sigma[t]
        var=max(decay*var+(1-decay)*r[t]**2,1e-12)
    return sigma,z

def forecast_from_past(zpast,sigma,n=250,gap=30,taus=np.array([.01,.05]),seed=123,B=199,Bsel=999):
    if len(zpast)<4*n+gap:raise ValueError('Insufficient residual history.')
    h=np.asarray(zpast[-(4*n+gap):-(n+gap)]);r=np.asarray(zpast[-n:])
    if not np.isfinite(h).all() or not np.isfinite(r).all():raise ValueError('Residual warmup or missing values present.')
    grid=window_grid(n);K=len(grid);streams=[np.random.default_rng(s) for s in np.random.SeedSequence(seed).spawn(K+2)]
    ix,_,_,_=score_select_two_levels(r,streams[0],Bsel,10)
    bh=block_draws(h,taus,B,10,streams[1])[0];qh=quantile_from_sorted(np.sort(h),taus);vh=bh.var(axis=0,ddof=1)
    qs=[];vs=[];means=[]
    for j,m in enumerate(grid):
        y=r[-int(m):];bs=block_draws(y,taus,B,10,streams[j+2])[0]
        qs.append(quantile_from_sorted(np.sort(y),taus));vs.append(bs.var(axis=0,ddof=1));means.append(bs.mean(axis=0))
    qs,vs,means=map(np.asarray,(qs,vs,means));j=[K-1,ix]
    qb,bd=borrowing(qs[j],qh[None,:],vs[j],vh[None,:],means[j],B,.05)
    cv,_,cv1,_=cv_with_one_se(h,r,taus,10)
    values=np.stack([qs[-1],np.quantile(np.r_[h,r],taus),qb[0],qs[ix],qb[1],cv,cv1,norm.ppf(taus)],axis=-1)*sigma
    return values,{'selected_n':int(grid[ix]),'weights':bd['weight'][1].tolist(),
        'crossing_methods':[METHODS[j] for j in range(len(METHODS)) if np.any(np.diff(values[:,j])<0)]}

def hac_mean_se(x,lag=10):
    x=np.asarray(x,float);n=len(x);u=x-x.mean();v=np.dot(u,u)/n
    for ell in range(1,min(lag,n-1)+1):v+=2*(1-ell/(lag+1))*np.dot(u[ell:],u[:-ell])/n
    return math.sqrt(max(v,0)/n)

def bh_adjust(p):
    p=np.asarray(p,float);order=np.argsort(p);ranked=p[order]
    adj=np.minimum.accumulate((ranked*len(p)/np.arange(1,len(p)+1))[::-1])[::-1]
    out=np.empty_like(p);out[order]=np.minimum(adj,1);return out

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--input',type=Path,required=True);ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--test-start',default='2015-01-01');ap.add_argument('--test-end',default='2025-12-31');ap.add_argument('--industry',action='append')
    ap.add_argument('--n',type=int,default=250);ap.add_argument('--seed',type=int,default=2026101206);a=ap.parse_args()
    d=pd.read_csv(a.input);d['date']=pd.to_datetime(d['date']);d=d.sort_values('date').reset_index(drop=True)
    if d.date.duplicated().any():raise ValueError('Duplicate dates not allowed.')
    cols=a.industry or list(d.columns.drop('date'));taus=np.array([.01,.05]);records=[]
    # The CSV is percentage simple returns; maintain those units in all losses.
    for s,col in enumerate(cols):
        r=pd.to_numeric(d[col],errors='raise').to_numpy(float)
        if np.isin(r,[-99.99,-999.]).any() or not np.isfinite(r).all():raise ValueError('Missing sentinels/values; no imputation permitted.')
        sig,z=causal_filter(r)
        for t in range(250+4*a.n+30,len(d)):
            if not pd.Timestamp(a.test_start)<=d.date.iloc[t]<=pd.Timestamp(a.test_end):continue
            pred,diag=forecast_from_past(z[:t],sig[t],a.n,seed=[a.seed,s,t])
            for k,tau in enumerate(taus):
                for j,m in enumerate(METHODS):
                    q=float(pred[k,j]);u=r[t]-q
                    records.append({'date':str(d.date.iloc[t].date()),'industry':col,'tau':tau,'method':m,
                    'actual_return_percent':float(r[t]),'forecast_quantile_percent':q,'pinball_loss':float(u*(tau-(u<0))),
                    'hit':int(u<0),'selected_n':diag['selected_n'],'borrowing_weight':diag['weights'][k],
                    'crossing':int(m in diag['crossing_methods'])})
        print('Completed '+col,flush=True)
    if not records:raise ValueError('No eligible test observations. Check dates and warmup.')
    a.out.mkdir(parents=True,exist_ok=True);p=pd.DataFrame(records);p.to_csv(a.out/'predictions.csv',index=False)
    rows=[]
    for (col,tau,m),g in p.groupby(['industry','tau','method']):
        base=p[(p.industry==col)&(p.tau==tau)&(p.method=='recent')].set_index('date').pinball_loss
        loss=g.set_index('date').pinball_loss;diff=(loss-base).to_numpy();se=hac_mean_se(diff)
        pv=1. if se==0 else float(2*norm.sf(abs(diff.mean()/se)))
        N=len(g);hits=int(g.hit.sum());ph=hits/N
        lognull=xlogy(hits,tau)+xlogy(N-hits,1-tau)
        logalt=xlogy(hits,ph)+xlogy(N-hits,1-ph);lr=max(float(2*(logalt-lognull)),0.)
        rows.append({'industry':col,'tau':tau,'method':m,'n':N,'mean_pinball_loss':loss.mean(),
        'loss_ratio_vs_recent':float(loss.mean()/base.mean()),'hit_rate':ph,'uc_lr_p':float(chi2.sf(lr,1)),
        'loss_difference_vs_recent':float(diff.mean()),'hac_se_difference':se,'dm_normal_approx_p':pv,'crossing_count':int(g.crossing.sum())})
    sm=pd.DataFrame(rows);mask=sm.method!='recent';sm['bh_adjusted_dm_p']=np.nan;sm.loc[mask,'bh_adjusted_dm_p']=bh_adjust(sm.loc[mask,'dm_normal_approx_p'])
    sm.to_csv(a.out/'summary.csv',index=False)
    (a.out/'run_manifest.json').write_text(json.dumps({'input':str(a.input),'units':'percent daily simple returns','test_start':a.test_start,
    'test_end':a.test_end,'filter':'zero mean; EWMA decay=.94; first 250 observations initialize variance; all residuals use one-step-ahead sigma',
    'risk_budget':.05,'selection_alpha':.01,'selector_bootstrap_reps':999,'quantile_bootstrap_reps':199,'gap':30,
    'recent_n':a.n,'past_only':True,'monotonicity':'crossings reported, not repaired','inferential_scope':'HAC-normal DM and UC asymptotic reference p-values; not post-selection finite-sample guarantees'},indent=2))
if __name__=='__main__':main()
