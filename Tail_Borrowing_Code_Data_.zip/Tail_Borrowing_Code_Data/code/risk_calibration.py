"""Risk-budget calibration for the local Gaussian experiment.

Let a = v_R - c, s = v_R+v_H-2c, kappa = a^2/(s*v_R).
Assume 0 < a <= s, so clipping is inactive. With known moments, the
Gaussian MSE satisfies R(d)/v_R <= 1 + kappa*M(lambda), for all shifts d.
This is NOT a finite-sample guarantee for empirical time-series quantiles
with estimated moments. See the theory note for assumptions and proof.
"""
from __future__ import annotations
from functools import lru_cache
import numpy as np


def envelope(penalty: np.ndarray | float) -> np.ndarray:
    lam = np.asarray(penalty, dtype=float)
    if np.any(lam < 0):
        raise ValueError('Penalty must be nonnegative.')
    A = 1 + lam**2
    arg = np.clip(18*lam/(7*np.sqrt(7*A)), -1., 1.)
    u = 2*np.sqrt(7*A)/3*np.cos(np.arccos(arg)/3)
    return (3*u*u - 2*A)/(1+(u+lam)**2)**2


@lru_cache(maxsize=16)
def _lookup(eta: float) -> tuple[np.ndarray, np.ndarray]:
    if not 0 < eta < 1:
        raise ValueError('Use a risk budget in (0, 1).')
    kappas = np.linspace(0., 1., 10001)
    lo, hi = np.zeros_like(kappas), np.ones_like(kappas)
    while np.any(kappas*envelope(hi) > eta):
        hi *= 2
    for _ in range(60):
        mid = (lo + hi)/2
        needs_more_penalty = kappas*envelope(mid) > eta
        lo = np.where(needs_more_penalty, mid, lo)
        hi = np.where(needs_more_penalty, hi, mid)
    hi = np.where(.45*kappas <= eta, 0., hi)
    return kappas, hi


def calibrate(kappa: np.ndarray | float, eta: float = .05) -> np.ndarray:
    k = np.asarray(kappa, dtype=float)
    if np.any(~np.isfinite(k)) or np.any((k < 0) | (k > 1+1e-10)):
        raise ValueError('kappa must lie in [0, 1].')
    grid, penalties = _lookup(float(eta))
    # Round kappa upward; this conservatively preserves the envelope inequality.
    index = np.searchsorted(grid, np.minimum(k, 1.), side='left')
    return penalties[index]


if __name__ == '__main__':
    kappas = np.linspace(0, 1, 10001)
    lam = calibrate(kappas, .05)
    assert np.max(kappas*envelope(lam)) <= .05 + 1e-12
    for k in [.5, .75, 1.]:
        p = float(calibrate(k, .05))
        print(f'kappa={k:.2f} lambda={p:.9f} upper risk ratio={1+k*float(envelope(p)):.9f}')
