#!/usr/bin/env python3
"""Validate the retained arrays, frozen inputs, and complete summary coverage."""
from pathlib import Path
import hashlib
import json

import numpy as np
import pandas as pd
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    manifest = json.loads((ROOT / "docs/experiment_manifest.json").read_text())
    precision = json.loads((ROOT / "docs/precision_manifest.json").read_text())
    assert digest(ROOT / "docs/experiment_manifest.json") == (
        ROOT / "docs/experiment_manifest_sha256.txt").read_text().strip()
    data_path = ROOT / "data/french12_value_weighted_2000_2025_percent.csv"
    assert digest(data_path) == manifest["data_sha256"]
    for name in ("financial_pre_run_code_hashes.json",
                 "simulation_pre_run_code_hashes.json",
                 "precision_pre_run_code_hashes.json"):
        for file, expected in json.loads((ROOT / "docs" / name).read_text()).items():
            assert digest(ROOT / "code" / file) == expected, (name, file)

    data = pd.read_csv(data_path)
    financial = pd.read_csv(ROOT / "tables/financial_summary.csv").set_index(
        ["config", "industry", "tau", "method"])
    assert financial.index.is_unique and len(financial) == 3240
    expected_financial = {
        (cfg["id"], industry, tau, method)
        for cfg in manifest["financial_configs"]
        for industry in manifest["industries"] for tau in (.01, .05)
        for method in financial.index.get_level_values("method").unique()}
    assert set(financial.index) == expected_financial
    for col in ("dm_bh_p", "dm_bh_p_original8", "uc_bh_p", "ind_bh_p", "cc_bh_p"):
        values = financial[col].dropna()
        assert values.between(0, 1).all()

    financial_values = 0
    for industry in manifest["industries"]:
        path = ROOT / "results/financial/main" / f"{industry}.npz"
        meta = json.loads(path.with_suffix(".json").read_text())
        assert digest(path) == meta["npz_sha256"]
        with np.load(path, allow_pickle=False) as a:
            indices, actual = a["origin_index"], a["actual_return_percent"]
            q, taus, losses = a["forecasts"], a["taus"], a["pinball_loss"]
            assert len(indices) == 2766
            assert np.array_equal(data[industry].to_numpy()[indices], actual)
            assert np.array_equal(data.date.to_numpy()[indices].astype("U10"), a["dates"])
            assert np.isfinite(q).all() and np.isfinite(losses).all()
            difference = actual[:, None, None] - q
            assert np.array_equal((difference < 0).astype(np.int8), a["hits"])
            assert np.array_equal(np.diff(q, axis=1)[:, 0, :] < 0, a["crossings"])
            np.testing.assert_allclose(losses, difference * (
                taus[None, :, None] - (difference < 0)), rtol=0, atol=1e-14)
            assert np.all((a["selected_weight"] >= 0) & (a["selected_weight"] <= 1))
            assert np.all(np.abs(q[:, :, 4] - q[:, :, 3]) <=
                          a["selected_radius_percent"] + 1e-10)
            for ti, tau in enumerate(taus):
                for mi, method in enumerate(a["methods"]):
                    row = financial.loc[("main", industry, float(tau), method)]
                    assert abs(row.mean_pinball_loss - losses[:, ti, mi].mean()) < 1e-12
                    assert abs(row.loss_ratio - losses[:, ti, mi].mean() /
                               losses[:, ti, 0].mean()) < 1e-12
                    assert int(row.violations) == int(a["hits"][:, ti, mi].sum())
            financial_values += q.size

    simulation_rows = 0
    for settings, filename in (
            (manifest["simulation"], "simulation_summary.csv"),
            (precision["simulation"], "precision_simulation_summary.csv")):
        table = pd.read_csv(ROOT / "tables" / filename).set_index(
            ["family", "scenario", "phi", "n_recent", "tau", "method"])
        methods = table.index.get_level_values("method").unique()
        assert table.index.is_unique and len(methods) == 12
        expected = {(c["family"], c["scenario"], c["phi"], c["n_recent"], tau, method)
                    for c in settings["cells"] for tau in settings["taus"]
                    for method in methods}
        assert set(table.index) == expected
        assert (table.reps == settings["reps"]).all()
        assert np.isfinite(table[["mse", "bias", "relative_mse", "ratio_mcse"]]).all().all()
        assert (table[["mse", "relative_mse", "ratio_mcse"]] >= 0).all().all()
        simulation_rows += len(table)

    references = list((ROOT / "results/reference").rglob("*.npz"))
    assert len(references) == 5
    for path in references:
        meta = json.loads(path.with_suffix(".json").read_text())
        assert digest(path) == meta["npz_sha256"]
        with np.load(path, allow_pickle=False) as a:
            if "estimates" in a.files:
                assert len(a["estimates"]) == 3
                assert np.isfinite(a["estimates"]).all()
                assert meta["retained_replication_indices"] == [0, 1, 2]
            else:
                assert np.array_equal(a["reference_position"], [0, 2765])
                assert len(a["dates"]) == 2 and np.isfinite(a["forecasts"]).all()

    tables = list((ROOT / "tables").glob("*.csv"))
    assert len(tables) == 12
    figures = json.loads((ROOT / "docs/figures_index.json").read_text())
    assert len(figures) == 9
    for item in figures:
        with Image.open(ROOT / item["file"]) as image:
            image.verify()
    print(json.dumps({"status": "PASS", "verification_scope": "compact release",
        "frozen_data_and_model_hashes_match": True,
        "main_financial_result_files": 12, "main_financial_forecast_values": financial_values,
        "main_arrays_and_summary_values_reconciled": True,
        "financial_summary_rows_all_designs": len(financial),
        "simulation_summary_rows_all_designs": simulation_rows,
        "validation_reference_files": len(references), "summary_csv_files": len(tables),
        "png_files_validated": len(figures),
        "full_secondary_financial_and_simulation_arrays_included": False}, indent=2))


if __name__ == "__main__":
    main()
