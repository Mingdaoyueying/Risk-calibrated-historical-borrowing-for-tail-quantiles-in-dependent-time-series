#!/usr/bin/env python3
"""Frozen financial application and one-factor sensitivities; all past-data forecasts."""
from __future__ import annotations
import argparse, hashlib, json, os, time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import norm
from adaptive import window_grid, borrowing, lepski_select
from adaptive_refined import score_select_two_levels, cv_with_one_se
from estimator import block_draws, quantile_from_sorted, bias_calibrate
from financial_backtest import causal_filter

ROOT=Path(__file__).resolve().parents[1]
PRIMARY_METHODS=('recent','pooled','fixed_bias_borrow','score_only_01','score_borrow_01','cv_window','cv_one_se','ewma_normal')
METHODS=PRIMARY_METHODS+('short_recent','lepski_only','score_only_10','score_borrow_10','no_borrow_after_shortening','plugin','risk_original')
TAUS=np.array([.01,.05])

def forecast_bundle(zpast,sigma,cfg,seed):
    n=cfg['n_recent'];gap=cfg['gap'];B=cfg['bootstrap_reps'];block=cfg['block_length'];eta=cfg['risk_budget']
    if len(zpast)<4*n+gap:raise ValueError('Insufficient residual history')
    hist=np.asarray(zpast[-(4*n+gap):-(n+gap)]);recent=np.asarray(zpast[-n:])
    if not np.isfinite(hist).all() or not np.isfinite(recent).all():raise ValueError('Nonfinite historical residuals')
    grid=window_grid(n);K=len(grid)
    streams=[np.random.default_rng(s) for s in np.random.SeedSequence(seed).spawn(K+2)]
    ix,j10,d1,d10=score_select_two_levels(recent,streams[0],cfg['selector_bootstrap_reps'],block)
    bh=block_draws(hist,TAUS,B,block,streams[1])[0]
    qh=quantile_from_sorted(np.sort(hist),TAUS);vh=bh.var(axis=0,ddof=1)
    qs=[];vs=[];means=[]
    for j,m in enumerate(grid):
        y=recent[-int(m):];bs=block_draws(y,TAUS,B,block,streams[j+2])[0]
        qs.append(quantile_from_sorted(np.sort(y),TAUS));vs.append(bs.var(axis=0,ddof=1));means.append(bs.mean(axis=0))
    qs,vs,means=map(np.asarray,(qs,vs,means))
    # Keep the original eight outputs in their original order and arithmetic.
    qb,bd=borrowing(qs[[K-1,ix]],qh[None,:],vs[[K-1,ix]],vh[None,:],means[[K-1,ix]],B,eta)
    cv,cv_n,cv1,cv1_n=cv_with_one_se(hist,recent,TAUS,10)
    original=[qs[-1],np.quantile(np.r_[hist,recent],TAUS),qb[0],qs[ix],qb[1],cv,cv1,norm.ppf(TAUS)]
    qb10,bd10=borrowing(qs[[j10]],qh[None,:],vs[[j10]],vh[None,:],means[[j10]],B,eta)
    lp=lepski_select(qs,vs,.1)
    vr=np.maximum(vs[-1],1e-14);vhh=np.maximum(vh,1e-14);s=vr+vhh;delta=qh-qs[-1]
    wplugin=vr/(s+delta**2)
    lam_original=bias_calibrate(vr/s,np.zeros_like(vr),eta)
    woriginal=vr/(s+(np.abs(delta)+lam_original*np.sqrt(s))**2)
    gate=qs[ix] if ix<K-1 else qb[1]
    values=np.stack(original+[qs[0],qs[lp,np.arange(len(TAUS))],qs[j10],qb10[0],gate,
                             qs[-1]+wplugin*delta,qs[-1]+woriginal*delta],axis=-1)*sigma
    diag={'selected_n':int(grid[ix]),'selected_n10':int(grid[j10]),
      'lepski_n':grid[lp],'cv_n':cv_n,'cv_one_se_n':cv1_n,
      'selected_weight':bd['weight'][1],'fixed_weight':bd['weight'][0],
      'selected_lambda':bd['lambda'][1],'selected_beta':bd['beta'][1],
      'selected_radius_percent':bd['radius'][1]*sigma,
      'plugin_weight':wplugin,'original_weight':woriginal,
      'selector_critical':d1['score_critical'],'selector_parent_statistics':d1['score_parent_statistics'],
      'quantile_grid_percent':qs*sigma}
    assert np.all(np.abs(values[:,4]-values[:,3])<=diag['selected_radius_percent']+1e-10)
    return values,diag

def run_industry(cfg,col,s,out):
    started=time.perf_counter();data=pd.read_csv(ROOT/'data/french12_value_weighted_2000_2025_percent.csv')
    dates=pd.to_datetime(data.date);ret=data[col].to_numpy(float)
    sigma,z=causal_filter(ret,decay=cfg['ewma_decay'],burn=cfg['burn'])
    eligible=np.flatnonzero((dates>=cfg['test_start'])&(dates<=cfg['test_end']))
    eligible=eligible[eligible>=cfg['burn']+4*cfg['n_recent']+cfg['gap']]
    if len(eligible)!=2766:raise ValueError('All designs must use the same 2766 test dates')
    forecasts=np.empty((len(eligible),len(TAUS),len(METHODS)));diagnostics={}
    for i,t in enumerate(eligible):
        forecasts[i],d=forecast_bundle(z[:t],sigma[t],cfg,[cfg['seed'],s,int(t)])
        if i==0:
            diagnostics={k:np.empty((len(eligible),)+np.shape(v),dtype=int if k.endswith('_n') or k.startswith('selected_n') else float) for k,v in d.items()}
        for k,v in d.items():diagnostics[k][i]=v
    actual=ret[eligible];u=actual[:,None,None]-forecasts
    loss=u*(TAUS[None,:,None]-(u<0));hits=(u<0).astype(np.int8)
    out.mkdir(parents=True,exist_ok=True);target=out/f'{col}.npz';tmp=out/f'.{col}.tmp.npz'
    np.savez_compressed(tmp,dates=dates.iloc[eligible].dt.strftime('%Y-%m-%d').to_numpy(dtype='U10'),
        origin_index=eligible,industry=col,taus=TAUS,methods=np.array(METHODS),primary_methods=np.array(PRIMARY_METHODS),
        actual_return_percent=actual,sigma_percent=sigma[eligible],forecasts=forecasts,pinball_loss=loss,hits=hits,
        crossings=np.diff(forecasts,axis=1)[:,0,:]<0,**diagnostics)
    os.replace(tmp,target)
    elapsed=time.perf_counter()-started
    (out/f'{col}.json').write_text(json.dumps({'config':cfg,'industry':col,'global_industry_index':s,'test_dates':len(eligible),
        'elapsed_seconds':elapsed,'seed_protocol':'SeedSequence([config.seed, full_csv_industry_index, raw_origin_index])',
        'npz_sha256':hashlib.sha256(target.read_bytes()).hexdigest()},indent=2)+'\n')
    return cfg['id'],col,elapsed

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workers',type=int,default=8);parser.add_argument('--config',action='append');parser.add_argument('--resume',action='store_true')
    args=parser.parse_args();manifest=json.loads((ROOT/'docs/experiment_manifest.json').read_text())
    cols=manifest['industries'];configs=[c for c in manifest['financial_configs'] if not args.config or c['id'] in args.config]
    submitted=[]
    with ProcessPoolExecutor(max_workers=args.workers) as executor:
        for cfg in configs:
            out=ROOT/'results/financial'/cfg['id']
            for s,col in enumerate(cols):
                if args.resume and (out/f'{col}.json').exists() and (out/f'{col}.npz').exists():
                    meta=json.loads((out/f'{col}.json').read_text())
                    if meta['config']!=cfg:raise ValueError('Resume configuration mismatch')
                    if meta['npz_sha256']!=hashlib.sha256((out/f'{col}.npz').read_bytes()).hexdigest():raise ValueError('Resume file hash mismatch')
                    continue
                submitted.append(executor.submit(run_industry,cfg,col,s,out))
        for future in as_completed(submitted):
            cid,col,elapsed=future.result();print(f'Completed {cid}/{col}: {elapsed:.1f}s',flush=True)
    print('Financial forecast jobs complete.',flush=True)

if __name__=='__main__':main()
