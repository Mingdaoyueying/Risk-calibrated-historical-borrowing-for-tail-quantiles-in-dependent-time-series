"""Phase B, frozen after inspecting Phase A; not a preregistered confirmation.
Use alpha=.01 (instead of .10), and B=999. Add a paired-one-SE CV comparator.
Do not alter Phase A results or code. No finite-sample 5% selection guarantee.
"""
from __future__ import annotations
import numpy as np
from adaptive import window_grid, multiscale_select, borrowing, lepski_select
from estimator import quantile_from_sorted

def score_select_two_levels(x,rng,B=999,block=10):
    """Reuse exactly the same multiplier draws at .01 and .10 thresholds."""
    seed=int(rng.integers(0,2**63-1))
    j1,d1=multiscale_select(x,np.random.default_rng(seed),B=B,block=block,alpha=.01)
    j10,d10=multiscale_select(x,np.random.default_rng(seed),B=B,block=block,alpha=.10)
    assert j1>=j10
    return j1,j10,d1,d10

def cv_with_one_se(hist,recent,taus,stride=10):
    """Time-ordered CV and an additional paired-one-SE rule.
    Longest candidate within one HAC SE of the best mean validation loss.
    This stabilizes selection but does not supply a post-selection CI.
    """
    n=len(recent);x=np.r_[hist,recent]
    candidates=np.unique(np.r_[window_grid(n),2*n,3*n])
    origins=np.unique(np.r_[np.arange(len(x)-int(np.ceil(n/2)),len(x),stride),len(x)-1])
    scores=[]
    for m in candidates:
        ids=origins[:,None]-int(m)+np.arange(int(m))[None,:]
        qs=quantile_from_sorted(np.sort(x[ids],axis=1),taus)
        u=x[origins,None]-qs;scores.append(u*(taus[None,:]-(u<0)))
    scores=np.asarray(scores);losses=scores.mean(axis=1)
    best=len(candidates)-1-np.argmin(losses[::-1],axis=0);one=best.copy()
    V=len(origins);lag=max(1,int(V**(1/3)))
    for t in range(len(taus)):
        d=scores[:,:,t]-scores[best[t],:,t][None,:];dc=d-d.mean(axis=1)[:,None]
        lrv=np.mean(dc*dc,axis=1)
        for ell in range(1,lag+1):
            lrv+=2*(1-ell/(lag+1))*np.sum(dc[:,ell:]*dc[:,:-ell],axis=1)/V
        se=np.sqrt(np.maximum(lrv,0)/V)
        feasible=np.flatnonzero(d.mean(axis=1)<=se+1e-15)
        one[t]=feasible[-1]
    def refit(ids):
        return np.array([np.quantile(x[-int(candidates[j]):],float(t)) for j,t in zip(ids,taus)])
    return refit(best),candidates[best],refit(one),candidates[one]
