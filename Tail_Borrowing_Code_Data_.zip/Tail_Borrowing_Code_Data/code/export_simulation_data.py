#!/usr/bin/env python3
"""Export historical and recent observations from the frozen simulation seeds."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

from adaptive import window_grid
from simulation_run import sample, SCENARIOS_EXT

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--family", required=True)
    parser.add_argument("--scenario", required=True)
    parser.add_argument("--n-recent", type=int, default=250)
    parser.add_argument("--phi", type=float, default=0.6)
    parser.add_argument("--first-rep", type=int, default=0)
    parser.add_argument("--count", type=int, default=1)
    parser.add_argument("--out", type=Path, default=ROOT / "reruns/observations")
    args = parser.parse_args()
    manifest = "precision_manifest.json" if args.family.startswith("precision_") else "experiment_manifest.json"
    cfg = json.loads((ROOT / "docs" / manifest).read_text())["simulation"]
    cells = [c for c in cfg["cells"] if c["family"] == args.family
             and c["scenario"] == args.scenario and c["n_recent"] == args.n_recent
             and abs(c["phi"] - args.phi) < 1e-12]
    if len(cells) != 1:
        parser.error("Select one cell that exists in the frozen manifest")
    if args.first_rep < 0 or args.count < 1 or args.first_rep + args.count > cfg["reps"]:
        parser.error("Replication range is outside the frozen experiment")
    cell = cells[0]
    histories, recent, truths = [], [], []
    taus = np.asarray(cfg["taus"])
    for rep in range(args.first_rep, args.first_rep + args.count):
        sequence = np.random.SeedSequence([cfg["seed"], cell["n_recent"],
            int(round(cell["phi"] * 1000)), SCENARIOS_EXT.index(cell["scenario"]), rep])
        rng = np.random.default_rng(sequence.spawn(3 + len(window_grid(cell["n_recent"])))[0])
        h, r, truth = sample(cell["n_recent"], cell["phi"], cell["scenario"],
                             rng, cfg["gap"], taus)
        histories.append(h)
        recent.append(r)
        truths.append(truth)
    args.out.mkdir(parents=True, exist_ok=True)
    stem = (f"{args.family}_{args.scenario}_phi{cell['phi']:g}_n{cell['n_recent']}"
            f"_rep{args.first_rep}-{args.first_rep + args.count - 1}")
    path = args.out / f"{stem}.npz"
    np.savez_compressed(path, historical=np.asarray(histories), recent=np.asarray(recent),
                        truth=np.asarray(truths), taus=taus,
                        replication=np.arange(args.first_rep, args.first_rep + args.count))
    record = {"cell": cell, "seed": cfg["seed"], "gap": cfg["gap"],
              "first_replication": args.first_rep, "count": args.count,
              "historical_length": 3 * args.n_recent, "recent_length": args.n_recent,
              "source_manifest": manifest,
              "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
              "observation_type": "Monte Carlo observations generated from the frozen process and seeds"}
    path.with_suffix(".json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
