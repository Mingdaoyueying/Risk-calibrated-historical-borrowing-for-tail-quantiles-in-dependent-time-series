"""Bias-aware research candidates, not distribution-free risk guarantees."""
from __future__ import annotations
import math
import numpy as np
from scipy.stats import norm
from risk_calibration import envelope


def bias_calibrate(kappa, beta, eta=.05):
    """Calibrate Gaussian bound. Bootstrap bias proxies are NOT certified bounds."""
    k,b=np.broadcast_arrays(np.asarray(kappa,float),np.asarray(beta,float))
    if not 0<eta<1 or np.any(~np.isfinite(k)) or np.any(~np.isfinite(b)):
        raise ValueError('Finite inputs and eta in (0,1) required.')
    if np.any((k<0)|(k>1+1e-10)) or np.any(b<0):
        raise ValueError('Require kappa in [0,1], beta>=0.')
    k=np.minimum(k,1.)
    def bound(lam):
        return k*envelope(lam)+b*np.sqrt(k)/(np.hypot(1.,lam)+lam)
    lo,hi=np.zeros_like(k),np.ones_like(k)
    for _ in range(60):
        if np.all(bound(hi)<=eta):break
        hi*=2
    else:raise ArithmeticError('Unable to bracket calibration.')
    for _ in range(40):
        mid=(lo+hi)/2;need=bound(mid)>eta
        lo,hi=np.where(need,mid,lo),np.where(need,hi,mid)
    return np.where(bound(np.zeros_like(k))<=eta,0.,hi)


def quantile_from_sorted(xs,tau,method='linear'):
    """Quantiles from observations sorted along last axis; last output axis is tau."""
    n=xs.shape[-1]
    if method=='linear':index=(n-1)*tau
    elif method=='median_unbiased':index=(n+1/3)*tau-2/3
    else:raise ValueError(method)
    index=np.clip(index,0,n-1);lo=np.floor(index).astype(int);hi=np.minimum(lo+1,n-1);w=index-lo
    return xs[...,lo]*(1-w)+xs[...,hi]*w


def block_draws(x,taus,B,block,rng):
    if x.ndim!=1 or len(x)<2 or B<2 or block<1 or block>len(x):
        raise ValueError('Invalid block bootstrap input.')
    n=len(x);starts=rng.integers(0,n,size=(B,math.ceil(n/block),1))
    ids=((starts+np.arange(block))%n).reshape(B,-1)[:,:n]
    xs=np.sort(x[ids],axis=-1)
    return quantile_from_sorted(xs,taus),quantile_from_sorted(xs,taus,'median_unbiased')


def estimates_from_bootstrap(hist,recent,bh,br,taus,eta=.05):
    """No DGP parameters, true quantiles, or evaluation outcomes enter estimation.
    C=0 is only a pilot approximation for windows separated by a deliberate gap.
    """
    qh=quantile_from_sorted(np.sort(hist),taus);qr=quantile_from_sorted(np.sort(recent),taus)
    vh=np.maximum(bh[0].var(axis=0,ddof=1),1e-14);vr=np.maximum(br[0].var(axis=0,ddof=1),1e-14)
    s=vr+vh;d=qh-qr;k=vr/s;b=br[0].mean(axis=0)-qr
    # Second term covers only conditional Monte Carlo error in bootstrap mean.
    # Neither term provides a confidence bound on actual frequentist bias.
    beta=np.abs(b)/np.sqrt(vr)+norm.ppf(.95)/math.sqrt(len(br[0]))
    lam0=bias_calibrate(k,0.,eta);lamB=bias_calibrate(k,beta,eta)
    w0=vr/(s+(np.abs(d)+lam0*np.sqrt(s))**2)
    wB=vr/(s+(np.abs(d)+lamB*np.sqrt(s))**2)
    qh8=quantile_from_sorted(np.sort(hist),taus,'median_unbiased')
    qr8=quantile_from_sorted(np.sort(recent),taus,'median_unbiased')
    vh8=np.maximum(bh[1].var(axis=0,ddof=1),1e-14);vr8=np.maximum(br[1].var(axis=0,ddof=1),1e-14)
    s8=vr8+vh8;d8=qh8-qr8;lam8=bias_calibrate(vr8/s8,0.,eta)
    w8=vr8/(s8+(np.abs(d8)+lam8*np.sqrt(s8))**2)
    out={'recent':qr,'pooled':quantile_from_sorted(np.sort(np.r_[hist,recent]),taus),
         'plugin':qr+(vr/(s+d*d))*d,'risk_original':qr+w0*d,'risk_bias_guard':qr+wB*d,
         'recent_type8':qr8,'risk_type8':qr8+w8*d8,'recent_boot_bias_corrected':qr-b}
    diag={'variance_recent':vr,'variance_historical':vh,'boot_bias_recent':b,'beta_proxy':beta,
          'lambda_original':lam0,'lambda_bias_guard':lamB,'weight_original':w0,'weight_bias_guard':wB,'weight_type8':w8}
    return out,diag
