#!/usr/bin/env python3
"""1000-replication extension of all V3 Phase-B cells and frozen sensitivities."""
from __future__ import annotations
import argparse, hashlib, json, math, os, time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
import numpy as np
from scipy.stats import norm
from adaptive import window_grid, borrowing, lepski_select
from adaptive_refined import score_select_two_levels, cv_with_one_se
from estimator import block_draws, quantile_from_sorted
from run_refined import dgp_b, SCENARIOS_B, METHODS_B

ROOT=Path(__file__).resolve().parents[1]
SCENARIOS_EXT=SCENARIOS_B+('weak_location_down','weak_scale_up','weak_break50','weak_recur_scale50')

def sample(n,phi,sc,rng,gap,taus):
    if not sc.startswith('weak_'):return dgp_b(n,phi,sc,rng,gap,taus)
    hist,recent,truth=dgp_b(n,phi,'stable',rng,gap,taus)
    if sc=='weak_location_down':recent-=.15;truth-=.15
    elif sc=='weak_scale_up':recent*=1.1;truth*=1.1
    elif sc=='weak_break50':recent[-int(math.ceil(n/2)):]*=1.1;truth*=1.1
    elif sc=='weak_recur_scale50':recent[:n-int(math.ceil(n/2))]*=1.1
    else:raise ValueError(sc)
    return hist,recent,truth

def run_cell(cell,cfg,out):
    n,phi,sc=cell['n_recent'],cell['phi'],cell['scenario'];block=cell['block_length'];eta=cell['risk_budget']
    taus=np.asarray(cfg['taus']);grid=window_grid(n);K=len(grid);T=len(taus);R=cfg['reps'];B=cfg['bootstrap_reps']
    estimates=np.empty((R,T,len(METHODS_B)));selected=np.empty(R,int);selected10=np.empty(R,int)
    weight=np.empty((R,T));fixedw=np.empty((R,T));radii=np.empty((R,T));lam=np.empty((R,T));beta=np.empty((R,T))
    cv_n=np.empty((R,T),int);cv1_n=np.empty((R,T),int);lepski_n=np.empty((R,T),int);qgrid=np.empty((R,K,T))
    started=time.perf_counter()
    for rep in range(R):
        ss=np.random.SeedSequence([cfg['seed'],n,int(round(phi*1000)),SCENARIOS_EXT.index(sc),rep])
        streams=[np.random.default_rng(s) for s in ss.spawn(3+K)]
        hist,recent,truth=sample(n,phi,sc,streams[0],cfg['gap'],taus)
        ix,j10,d1,d10=score_select_two_levels(recent,streams[1],cfg['selector_bootstrap_reps'],block)
        bh=block_draws(hist,taus,B,block,streams[2])[0]
        qh=quantile_from_sorted(np.sort(hist),taus);vh=bh.var(axis=0,ddof=1);qs=[];vs=[];means=[]
        for j,m in enumerate(grid):
            y=recent[-int(m):];bs=block_draws(y,taus,B,block,streams[3+j])[0]
            qs.append(quantile_from_sorted(np.sort(y),taus));vs.append(bs.var(axis=0,ddof=1));means.append(bs.mean(axis=0))
        qs,vs,means=map(np.asarray,(qs,vs,means))
        qb,bd=borrowing(qs[[K-1,j10,ix]],qh[None,:],vs[[K-1,j10,ix]],vh[None,:],means[[K-1,j10,ix]],B,eta)
        lp=lepski_select(qs,vs,.1);cv,cn,cv1,cn1=cv_with_one_se(hist,recent,taus,cfg['cv_stride'])
        gate=qs[ix] if ix<K-1 else qb[2]
        estimates[rep]=np.stack([qs[-1],np.quantile(np.r_[hist,recent],taus),qb[0],qs[0],qs[lp,np.arange(T)],
            qs[j10],qb[1],qs[ix],qb[2],gate,cv,cv1],axis=-1)
        selected[rep]=grid[ix];selected10[rep]=grid[j10];weight[rep]=bd['weight'][2];fixedw[rep]=bd['weight'][0]
        radii[rep]=bd['radius'][2];lam[rep]=bd['lambda'][2];beta[rep]=bd['beta'][2]
        cv_n[rep]=cn;cv1_n[rep]=cn1;lepski_n[rep]=grid[lp];qgrid[rep]=qs
    ia=list(METHODS_B).index('score_only_01');ib=list(METHODS_B).index('score_borrow_01')
    assert np.all(np.abs(estimates[:,:,ib]-estimates[:,:,ia])<=radii+1e-10)
    errors=estimates-truth[None,:,None];RA=np.mean(errors[:,:,ia]**2,axis=0);RB=np.mean(errors[:,:,ib]**2,axis=0)
    assert np.all(RB<=(np.sqrt(RA)+np.sqrt(np.mean(radii*radii,axis=0)))**2+1e-10)
    out.mkdir(parents=True,exist_ok=True);stem=f'{sc}_phi{phi:g}_n{n}';target=out/f'{stem}.npz';tmp=out/f'.{stem}.tmp.npz'
    np.savez_compressed(tmp,estimates=estimates,truth=truth,taus=taus,methods=METHODS_B,grid=grid,quantile_grid=qgrid,
        selected_n=selected,selected_n10=selected10,adaptive_weight=weight,fixed_weight=fixedw,adjustment_radius=radii,
        adaptive_lambda=lam,beta_proxy=beta,cv_n=cv_n,cv_one_se_n=cv1_n,lepski_n=lepski_n)
    os.replace(tmp,target);elapsed=time.perf_counter()-started
    (out/f'{stem}.json').write_text(json.dumps({'cell':cell,'replications':R,'seed':cfg['seed'],'elapsed_seconds':elapsed,
        'seed_protocol':'SeedSequence([seed,n,round(1000*phi),SCENARIOS_EXT.index(scenario),rep]); independently spawned data/selector/bootstrap streams',
        'npz_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'pathwise_displacement_bound':True,'empirical_L2_bridge_bound':True},indent=2)+'\n')
    return cell['family'],stem,elapsed

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--workers',type=int,default=8);parser.add_argument('--resume',action='store_true')
    args=parser.parse_args();cfg=json.loads((ROOT/'docs/experiment_manifest.json').read_text())['simulation']
    futures=[]
    with ProcessPoolExecutor(max_workers=args.workers) as executor:
        for cell in cfg['cells']:
            out=ROOT/'results/simulation'/cell['family'];stem=f"{cell['scenario']}_phi{cell['phi']:g}_n{cell['n_recent']}"
            if args.resume and (out/f'{stem}.json').exists() and (out/f'{stem}.npz').exists():
                meta=json.loads((out/f'{stem}.json').read_text())
                if meta['cell']!=cell or meta['replications']!=cfg['reps']:raise ValueError('Resume simulation settings mismatch')
                if meta['npz_sha256']!=hashlib.sha256((out/f'{stem}.npz').read_bytes()).hexdigest():raise ValueError('Resume hash mismatch')
                continue
            futures.append(executor.submit(run_cell,cell,cfg,out))
        for future in as_completed(futures):
            family,stem,elapsed=future.result();print(f'Completed {family}/{stem}: {elapsed:.1f}s',flush=True)
    print('Expanded simulation jobs complete.',flush=True)

if __name__=='__main__':main()
