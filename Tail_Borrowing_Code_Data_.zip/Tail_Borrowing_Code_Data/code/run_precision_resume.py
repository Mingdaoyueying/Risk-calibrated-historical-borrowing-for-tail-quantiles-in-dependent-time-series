#!/usr/bin/env python3
"""Resume-capable driver for the unchanged independent precision experiments."""
from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import hashlib
import json
from pathlib import Path

from simulation_run import run_cell

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    cfg = json.loads((ROOT / "docs/precision_manifest.json").read_text())["simulation"]
    with ProcessPoolExecutor(max_workers=args.workers) as executor:
        futures = []
        for cell in cfg["cells"]:
            output = ROOT / "results/simulation" / cell["family"]
            stem = f"{cell['scenario']}_phi{cell['phi']:g}_n{cell['n_recent']}"
            path = output / f"{stem}.npz"
            record = output / f"{stem}.json"
            if args.resume and path.is_file() and record.is_file():
                meta = json.loads(record.read_text())
                if (meta["cell"] != cell or meta["replications"] != cfg["reps"]
                        or meta["seed"] != cfg["seed"]):
                    raise ValueError(f"Precision resume settings mismatch: {stem}")
                with path.open("rb") as file:
                    digest = hashlib.file_digest(file, "sha256").hexdigest()
                if digest != meta["npz_sha256"]:
                    raise ValueError(f"Precision resume hash mismatch: {stem}")
                continue
            futures.append(executor.submit(run_cell, cell, cfg, output))
        for future in as_completed(futures):
            family, stem, seconds = future.result()
            print(f"Completed {family}/{stem}: {seconds:.1f}s", flush=True)
    print("Independent precision experiments complete.", flush=True)


if __name__ == "__main__":
    main()
