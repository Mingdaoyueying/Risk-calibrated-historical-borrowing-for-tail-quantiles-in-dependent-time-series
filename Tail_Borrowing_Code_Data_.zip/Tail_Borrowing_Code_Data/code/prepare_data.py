#!/usr/bin/env python3
"""Use the frozen prepared sample or rebuild it from an official source ZIP."""
from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import urllib.request
import zipfile

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def prepare(destination: Path, *, input_zip: Path | None = None,
            download_raw: bool = False) -> dict:
    manifest = json.loads((ROOT / "docs/financial_source_manifest.json").read_text())
    destination = destination.resolve()
    prepared = ROOT / manifest["prepared_file"]
    if input_zip is None and not download_raw:
        if not prepared.is_file():
            raise FileNotFoundError(
                "The bundled prepared CSV is missing. Supply --input-zip with "
                "the frozen official archive or use --download-raw. Source: "
                + manifest["source_url"])
        digest = hashlib.sha256(prepared.read_bytes()).hexdigest()
        if digest != manifest["prepared_sha256"]:
            raise ValueError("Bundled prepared CSV differs from the frozen sample")
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination != prepared.resolve():
            shutil.copyfile(prepared, destination)
        return {"status": "PASS", "rows": manifest["rows"],
                "industries": manifest["industry_count"],
                "return_observations": manifest["observed_return_cells"],
                "sha256": digest, "units": "percent daily simple returns",
                "data_source": "bundled frozen prepared CSV"}
    if input_zip is not None and download_raw:
        raise ValueError("Choose either input_zip or download_raw")
    if input_zip is not None:
        raw = input_zip.resolve().read_bytes()
        data_source = "provided official source ZIP"
    else:
        request = urllib.request.Request(manifest["source_url"], headers={
            "User-Agent": "TailBorrowing-Reproducibility/1.0.1"})
        with urllib.request.urlopen(request, timeout=60) as response:
            raw = response.read()
        data_source = "downloaded official source ZIP"
    if hashlib.sha256(raw).hexdigest() != manifest["archive_sha256"]:
        raise ValueError(
            "Source ZIP differs from frozen CRSP vintage "
            + manifest["source_vintage"] + ". The live provider file may have "
            "changed. Use the bundled prepared CSV for the archived experiments "
            "or provide the original ZIP with --input-zip.")
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        if archive.testzip() is not None:
            raise ValueError("Raw download ZIP CRC mismatch")
        names = [n for n in archive.namelist() if n.lower().endswith(".csv")]
        if len(names) != 1:
            raise ValueError("Expected exactly one source CSV")
        content = archive.read(names[0])
    if hashlib.sha256(content).hexdigest() != manifest["unmodified_csv_sha256"]:
        raise ValueError("Unmodified source CSV hash mismatch")
    lines = content.decode("utf-8-sig").splitlines()
    heading = next(i for i, line in enumerate(lines)
                   if "Average Value Weighted Returns -- Daily" in line)
    first = next(i for i in range(heading + 1, len(lines))
                 if re.match(r"^\s*\d{8},", lines[i]))
    end = first
    while end < len(lines) and re.match(r"^\s*\d{8},", lines[end]):
        end += 1
    frame = pd.read_csv(io.StringIO("\n".join([lines[first - 1]] + lines[first:end])))
    frame.columns = [str(c).strip() for c in frame.columns]
    frame = frame.rename(columns={frame.columns[0]: "date"})
    frame["date"] = pd.to_datetime(frame.date.astype(str), format="%Y%m%d")
    columns = manifest["industry_columns"]
    if list(frame.columns[1:]) != columns:
        raise ValueError("Unexpected industry order")
    frame[columns] = frame[columns].apply(pd.to_numeric, errors="raise")
    frame = frame[frame.date.between(manifest["requested_start"],
                                    manifest["requested_end"])].copy()
    if (len(frame) != 6539 or frame.date.duplicated().any()
            or not frame.date.is_monotonic_increasing
            or frame[columns].isna().any().any()
            or frame[columns].isin([-99.99, -999.0]).any().any()):
        raise ValueError("Prepared sample failed coverage or missing-value checks")
    destination.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(destination, index=False, date_format="%Y-%m-%d", float_format="%.2f")
    digest = hashlib.sha256(destination.read_bytes()).hexdigest()
    if digest != manifest["prepared_sha256"]:
        raise ValueError("Rebuilt prepared CSV differs from the frozen sample")
    return {"status": "PASS", "rows": len(frame), "industries": len(columns),
            "return_observations": len(frame) * len(columns), "sha256": digest,
            "units": "percent daily simple returns", "data_source": data_source}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=ROOT /
                        "reruns/prepared/data/french12_value_weighted_2000_2025_percent.csv")
    source = parser.add_mutually_exclusive_group()
    source.add_argument("--input-zip", type=Path,
                        help="Rebuild from the original official ZIP (vintage 202608)")
    source.add_argument("--download-raw", action="store_true",
                        help="Download the official ZIP and require the frozen vintage")
    args = parser.parse_args()
    print(json.dumps(prepare(args.out, input_zip=args.input_zip,
                             download_raw=args.download_raw), indent=2))


if __name__ == "__main__":
    main()
