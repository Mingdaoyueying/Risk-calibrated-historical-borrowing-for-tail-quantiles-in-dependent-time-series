"""Selection + borrowing prototypes. No oracle information enters feasible rules.
The multiscale comparator follows local-homogeneity principles; it is not a
verbatim implementation of Spokoiny (2009) or a fitted CAViaR model.
"""
from __future__ import annotations
import math
import numpy as np
from scipy.stats import norm
from estimator import quantile_from_sorted, block_draws, bias_calibrate


def window_grid(n: int) -> np.ndarray:
    if n < 240: raise ValueError('Need at least 240 recent observations.')
    return np.unique(np.r_[np.maximum(60, np.ceil(n*np.array([.25,.50,.75])).astype(int)), n])


def multiscale_select(x: np.ndarray, rng: np.random.Generator, *, B: int=199,
                      block: int=10, alpha: float=.10) -> tuple[int, dict]:
    """Rank-score local-homogeneity selector with joint block-multiplier cutoff.
    Test every nested inner suffix against the older shell inside its parent.
    Scores at parent empirical quantiles .10,.25,.50,.75,.90; bounded scores.
    A common family-wise bootstrap maximum cutoff covers all pairs and scores.
    Stop at the first rejected extension. The minimum suffix is not tested.
    Finite-sample size or post-selection risk validity is not claimed.
    """
    x=np.asarray(x,float);n=len(x);grid=window_grid(n)
    ps=np.array([.1,.25,.5,.75,.9]);vectors=[];parents=[]
    for k in range(1,len(grid)):
        m=int(grid[k]);y=x[-m:];q=np.quantile(y,ps)
        score=(y[:,None]<=q).astype(float);score-=score.mean(axis=0)
        for j in range(k):
            inner=int(grid[j]);outer=m-inner
            weights=np.r_[np.full(outer,-1/outer),np.full(inner,1/inner)]
            v=np.zeros((n,len(ps)));v[-m:]=weights[:,None]*score
            vectors.append(v);parents.extend([k]*len(ps))
    V=np.concatenate(vectors,axis=1)
    # Align the blocks at the forecast endpoint. The first block can be short.
    pad=(-n)%block
    P=np.pad(V,((pad,0),(0,0))).reshape(-1,block,V.shape[1]).sum(axis=1)
    se=np.sqrt((P*P).sum(axis=0));se=np.maximum(se,1e-12)
    stat=np.abs(V.sum(axis=0))/se
    multipliers=rng.standard_normal((B,len(P)))
    null=np.abs(multipliers@P)/se[None,:]
    critical=float(np.quantile(null.max(axis=1),1-alpha,method='higher'))
    selected=0;parent_max=[];parents=np.asarray(parents)
    for k in range(1,len(grid)):
        tk=float(stat[parents==k].max());parent_max.append(tk)
        if tk>critical:break
        selected=k
    # Compute all parent maxima for diagnostics, not only tested extensions.
    all_max=np.array([float(stat[parents==k].max()) for k in range(1,len(grid))])
    return selected,{'score_critical':critical,'score_parent_statistics':all_max}


def lepski_select(q: np.ndarray, variances: np.ndarray, alpha: float=.1) -> np.ndarray:
    """Tail-specific Lepski-type comparator, using sums of standard errors.
    All shorter candidates must agree with an extension. No independence of
    nested quantile estimates is assumed in the standard-error sum.
    This is a reference comparator, not claimed as a new contribution.
    """
    K,T=q.shape;z=norm.ppf(1-alpha/(K*(K-1)))
    choice=np.zeros(T,dtype=int)
    se=np.sqrt(np.maximum(variances,1e-14))
    for t in range(T):
        for k in range(1,K):
            if np.any(np.abs(q[k,t]-q[:k,t])>z*(se[k,t]+se[:k,t])):break
            choice[t]=k
    return choice


def borrowing(qr: np.ndarray, qh: np.ndarray, vr: np.ndarray, vh: np.ndarray,
              boot_mean: np.ndarray, B: int=199, eta: float=.05) -> tuple[np.ndarray,dict]:
    """Reuse V2 bias-aware rule with C=0 (deliberately separated windows).
    Bootstrap bias proxy is not a certified bias confidence bound. Selecting a
    window and conditioning a bootstrap on it does not resolve selection bias.
    """
    vr=np.maximum(vr,1e-14);vh=np.maximum(vh,1e-14);s=vr+vh;k=vr/s
    beta=np.abs(boot_mean-qr)/np.sqrt(vr)+norm.ppf(.95)/math.sqrt(B)
    lam=bias_calibrate(k,beta,eta);d=qh-qr
    w=vr/(s+(np.abs(d)+lam*np.sqrt(s))**2)
    adjustment=w*d
    radius=vr/(2*np.sqrt(s)*(np.hypot(1.,lam)+lam))
    assert np.all(np.abs(adjustment)<=radius+1e-10)
    return qr+adjustment,{'weight':w,'lambda':lam,'beta':beta,'radius':radius}


def prequential_window(hist: np.ndarray, recent: np.ndarray, taus: np.ndarray,
                       stride: int=10) -> tuple[np.ndarray,np.ndarray,np.ndarray]:
    """Competitive time-ordered pinball-CV comparator. Fit using strictly earlier
    observations at each validation origin; the validation observations are all
    past data for the endpoint estimation target. Refit after window selection.
    Both original historical and recent blocks are used; the gap is unobserved.
    Ties favour longer windows. No true endpoint quantile is used.
    """
    n=len(recent);x=np.r_[hist,recent]
    candidates=np.unique(np.r_[window_grid(n),2*n,3*n])
    origins=np.unique(np.r_[np.arange(len(x)-math.ceil(n/2),len(x),stride),len(x)-1])
    losses=np.zeros((len(candidates),len(taus)))
    for i,m in enumerate(candidates):
        ids=origins[:,None]-int(m)+np.arange(int(m))[None,:]
        qs=quantile_from_sorted(np.sort(x[ids],axis=1),taus)
        u=x[origins,None]-qs
        losses[i]=(u*(taus[None,:]-(u<0))).mean(axis=0)
    # Deterministically resolve exact ties in favour of more data.
    choice=len(candidates)-1-np.argmin(losses[::-1],axis=0)
    q=np.array([np.quantile(x[-int(candidates[j]):],float(t)) for j,t in zip(choice,taus)])
    return q,candidates[choice],losses
