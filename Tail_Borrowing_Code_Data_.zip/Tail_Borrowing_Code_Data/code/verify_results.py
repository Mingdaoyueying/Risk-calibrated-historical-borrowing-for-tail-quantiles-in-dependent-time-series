#!/usr/bin/env python3
"""Independent output reconciliation, frozen-code/data hashes and complete-cell audit."""
from pathlib import Path
import csv,gzip,hashlib,json
import numpy as np
import pandas as pd
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]

def main():
    manifest=json.loads((ROOT/'docs/experiment_manifest.json').read_text());h=hashlib.sha256((ROOT/'docs/experiment_manifest.json').read_bytes()).hexdigest()
    assert h==(ROOT/'docs/experiment_manifest_sha256.txt').read_text().strip()
    assert hashlib.sha256((ROOT/'data/french12_value_weighted_2000_2025_percent.csv').read_bytes()).hexdigest()==manifest['data_sha256']
    for file in ['financial_pre_run_code_hashes.json','simulation_pre_run_code_hashes.json','precision_pre_run_code_hashes.json']:
        for name,expected in json.loads((ROOT/'docs'/file).read_text()).items():
            assert hashlib.sha256((ROOT/'code'/name).read_bytes()).hexdigest()==expected,(file,name)
    data=pd.read_csv(ROOT/'data/french12_value_weighted_2000_2025_percent.csv')
    fs=pd.read_csv(ROOT/'tables/financial_summary.csv').set_index(['config','industry','tau','method'])
    assert fs.index.is_unique and len(fs)==3240
    origins=0;forecast_values=0;crossings=0;financial_files=0
    for cfg in manifest['financial_configs']:
        for col in manifest['industries']:
            p=ROOT/'results/financial'/cfg['id']/f'{col}.npz';meta=json.loads(p.with_suffix('.json').read_text())
            assert meta['config']==cfg and meta['npz_sha256']==hashlib.sha256(p.read_bytes()).hexdigest()
            with np.load(p) as a:
                arrays={k:a[k] for k in ['origin_index','dates','methods','taus','actual_return_percent','forecasts','pinball_loss','hits','crossings','selected_weight','selected_radius_percent']}
            ix=arrays['origin_index'];actual=arrays['actual_return_percent'];q=arrays['forecasts'];taus=arrays['taus'];loss=arrays['pinball_loss']
            assert len(ix)==2766 and np.array_equal(data[col].to_numpy()[ix],actual)
            assert np.array_equal(data.date.to_numpy()[ix].astype('U10'),arrays['dates'])
            assert np.isfinite(q).all() and np.isfinite(loss).all()
            difference=actual[:,None,None]-q
            assert np.array_equal((difference<0).astype(np.int8),arrays['hits'])
            assert np.array_equal(np.diff(q,axis=1)[:,0,:]<0,arrays['crossings'])
            assert np.allclose(loss,difference*(taus[None,:,None]-(difference<0)),rtol=0,atol=1e-14)
            assert np.all((arrays['selected_weight']>=0)&(arrays['selected_weight']<=1))
            assert np.all(np.abs(q[:,:,4]-q[:,:,3])<=arrays['selected_radius_percent']+1e-10)
            for ti,tau in enumerate(taus):
                for mi,method in enumerate(arrays['methods']):
                    row=fs.loc[(cfg['id'],col,float(tau),method)]
                    assert abs(row.mean_pinball_loss-float(loss[:,ti,mi].mean()))<1e-12
                    assert abs(row.loss_ratio-float(loss[:,ti,mi].mean()/loss[:,ti,0].mean()))<1e-12
                    assert int(row.violations)==int(arrays['hits'][:,ti,mi].sum())
            origins+=len(ix);forecast_values+=q.size;crossings+=int(arrays['crossings'].sum());financial_files+=1
    paths=0;sim_files=0;sim_quantile_cells=0;method_cells=0
    for settings,summary_file in [(manifest['simulation'],'simulation_summary.csv'),
             (json.loads((ROOT/'docs/precision_manifest.json').read_text())['simulation'],'precision_simulation_summary.csv')]:
        table=pd.read_csv(ROOT/'tables'/summary_file).set_index(['family','scenario','phi','n_recent','tau','method'])
        assert table.index.is_unique
        for cell in settings['cells']:
            stem=f"{cell['scenario']}_phi{cell['phi']:g}_n{cell['n_recent']}";p=ROOT/'results/simulation'/cell['family']/f'{stem}.npz'
            meta=json.loads(p.with_suffix('.json').read_text());assert meta['npz_sha256']==hashlib.sha256(p.read_bytes()).hexdigest()
            assert meta['cell']==cell and meta['replications']==settings['reps']
            with np.load(p) as a:
                est=a['estimates'];truth=a['truth'];methods=list(a['methods']);taus=a['taus'];radii=a['adjustment_radius']
                errors=est-truth[None,:,None];mse=np.mean(errors*errors,axis=0)
                assert len(est)==settings['reps'] and np.isfinite(errors).all()
                ia=methods.index('score_only_01');ib=methods.index('score_borrow_01')
                assert np.all(np.abs(est[:,:,ib]-est[:,:,ia])<=radii+1e-10)
                assert np.all(mse[:,ib]<=(np.sqrt(mse[:,ia])+np.sqrt(np.mean(radii*radii,axis=0)))**2+1e-10)
                for ti,tau in enumerate(taus):
                    for mi,method in enumerate(methods):
                        row=table.loc[(cell['family'],cell['scenario'],cell['phi'],cell['n_recent'],float(tau),method)]
                        assert abs(row.relative_mse-float(mse[ti,mi]/mse[ti,0]))<1e-10
            paths+=len(est);sim_files+=1;sim_quantile_cells+=len(taus);method_cells+=len(taus)*len(methods)
    rows=0
    with gzip.open(ROOT/'results/financial/main_predictions.csv.gz','rt',encoding='utf-8') as file:
        for row in csv.DictReader(file):rows+=1
    assert rows==995760
    figures=json.loads((ROOT/'docs/figures_index.json').read_text());assert len(figures)==9
    for figure in figures:
        with Image.open(ROOT/figure['file']) as image:image.verify()
    audit={'status':'PASS','all_frozen_manifest_and_model_hashes_match':True,'financial_result_files':financial_files,
      'forecast_origin_design_rows':origins,'financial_forecast_values':forecast_values,'main_daily_csv_rows':rows,
      'all_financial_losses_hits_dates_and_summaries_reconciled':True,'all_crossings_retained':True,'total_crossing_date_method_events_all_designs':crossings,
      'new_simulation_paths':paths,'new_simulation_dgp_files':sim_files,'new_simulation_quantile_cells':sim_quantile_cells,
      'new_simulation_method_cells':method_cells,'all_simulation_mse_and_bounds_reconciled':True,'png_files_validated':len(figures)}
    (ROOT/'docs/final_verification.json').write_text(json.dumps(audit,indent=2)+'\n');print(json.dumps(audit,indent=2))

if __name__=='__main__':main()
