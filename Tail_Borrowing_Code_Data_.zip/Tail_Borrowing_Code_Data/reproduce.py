#!/usr/bin/env python3
"""Portable entry point for the archived code and data release."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def execute(script: Path, *args: str) -> None:
    subprocess.run([sys.executable, str(script), *map(str, args)], check=True)


def release_hashes() -> None:
    path = ROOT / "SHA256SUMS.txt"
    if not path.is_file():
        raise FileNotFoundError("Release checksum file SHA256SUMS.txt is missing")
    count = 0
    for line in path.read_text(encoding="utf-8").splitlines():
        expected, name = line.split("  ", 1)
        file = ROOT / name
        with file.open("rb") as handle:
            digest = hashlib.file_digest(handle, "sha256").hexdigest()
        if digest != expected:
            raise ValueError(f"Release checksum mismatch: {name}")
        count += 1
    print(f"Release checksums verified: {count} files.", flush=True)


def initialize(target: Path) -> None:
    if target == ROOT or ROOT.is_relative_to(target):
        raise ValueError("Choose a separate output directory, not the release or its parent")
    target.mkdir(parents=True, exist_ok=True)
    for name in ("code", "docs", "data"):
        shutil.copytree(ROOT / name, target / name, dirs_exist_ok=True,
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    for name in ("raw", "results", "tables", "figures"):
        (target / name).mkdir(exist_ok=True)


def complete_results(target: Path) -> bool:
    manifest = json.loads((target / "docs/experiment_manifest.json").read_text())
    precision = json.loads((target / "docs/precision_manifest.json").read_text())
    paths = [target / "results/financial" / cfg["id"] / f"{industry}.npz"
             for cfg in manifest["financial_configs"] for industry in manifest["industries"]]
    for settings in (manifest["simulation"], precision["simulation"]):
        paths.extend(target / "results/simulation" / cell["family"] /
                     f"{cell['scenario']}_phi{cell['phi']:g}_n{cell['n_recent']}.npz"
                     for cell in settings["cells"])
    return all(path.is_file() for path in paths)


def verify(target: Path) -> None:
    execute(target / "code" / ("verify_results.py" if complete_results(target)
                               else "verify_package.py"))


def summarize(target: Path) -> None:
    if complete_results(target):
        execute(target / "code/analyze_results.py")
    else:
        print("Using retained summaries; regenerate all omitted arrays with --stage all.",
              flush=True)
        for path in (ROOT / "tables").glob("*.csv"):
            shutil.copy2(path, target / "tables" / path.name)
    execute(target / "code/summary_overviews.py")
    execute(target / "code/plot_results.py")
    verify(target)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", required=True, choices=(
        "verify", "prepare", "smoke", "summarize", "financial",
        "simulation", "precision", "all"))
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--resume", action="store_true")
    source = parser.add_mutually_exclusive_group()
    source.add_argument("--input-zip", type=Path,
                        help="Rebuild the data from the frozen official source ZIP")
    source.add_argument("--download-raw", action="store_true",
                        help="Download the source ZIP; require CRSP vintage 202608")
    args = parser.parse_args()
    if args.workers < 1:
        parser.error("--workers must be positive")
    if (args.input_zip is not None or args.download_raw) and args.stage not in (
            "prepare", "smoke", "financial", "all"):
        parser.error("Source ZIP options apply to prepare, smoke, financial, or all")
    data_args = (["--input-zip", str(args.input_zip.resolve())]
                 if args.input_zip is not None else
                 ["--download-raw"] if args.download_raw else [])
    for variable in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS",
                     "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
        os.environ[variable] = "1"

    if args.stage == "verify":
        if args.output_dir:
            target = args.output_dir.resolve()
            verify(target)
        else:
            release_hashes()
            verify(ROOT)
        return
    target = (args.output_dir or ROOT / "reruns" / args.stage).resolve()
    if target == ROOT or ROOT.is_relative_to(target):
        parser.error("--output-dir must be separate from the release and its parent")
    if args.stage == "prepare":
        execute(ROOT / "code/prepare_data.py", "--out",
                target / "data/french12_value_weighted_2000_2025_percent.csv", *data_args)
        return
    if args.stage == "smoke":
        execute(ROOT / "code/smoke_test.py", "--out", target, *data_args)
        return

    initialize(target)
    if args.stage == "summarize":
        if not complete_results(target):
            for path in (ROOT / "results").rglob("*"):
                if path.is_file():
                    destination = target / "results" / path.relative_to(ROOT / "results")
                    if not destination.exists():
                        destination.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(path, destination)
        summarize(target)
        return

    resume = ["--resume"] if args.resume else []
    if args.stage in ("financial", "all"):
        execute(target / "code/prepare_data.py", "--out",
                target / "data/french12_value_weighted_2000_2025_percent.csv", *data_args)
        execute(target / "code/financial_run.py", "--workers", args.workers, *resume)
    if args.stage in ("simulation", "all"):
        execute(target / "code/simulation_run.py", "--workers", args.workers, *resume)
    if args.stage in ("precision", "all"):
        execute(target / "code/run_precision_resume.py", "--workers", args.workers, *resume)
    if args.stage == "all":
        summarize(target)
    print(f"Completed stage {args.stage}; outputs: {target}", flush=True)


if __name__ == "__main__":
    main()
