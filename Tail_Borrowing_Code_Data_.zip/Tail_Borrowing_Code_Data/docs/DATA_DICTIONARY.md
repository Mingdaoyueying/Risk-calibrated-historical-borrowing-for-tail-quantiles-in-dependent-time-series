# Data and array dictionary

## Real financial observations

The complete provider CSV contains separate value-weighted and equal-weighted
daily blocks. The prepared sample uses the value-weighted block only. Original
download archives and the complete provider CSV are omitted from this release;
official download links and frozen source hashes are retained in the README
and `financial_source_manifest.json`.

`data/french12_value_weighted_2000_2025_percent.csv` has one row per source
trading date and these columns:

| Column | Meaning |
|---|---|
| `date` | Trading date in YYYY-MM-DD format |
| `NoDur` | Consumer nondurables |
| `Durbl` | Consumer durables |
| `Manuf` | Manufacturing |
| `Enrgy` | Energy |
| `Chems` | Chemicals |
| `BusEq` | Business equipment |
| `Telcm` | Telecommunications |
| `Utils` | Utilities |
| `Shops` | Wholesale, retail, and selected services |
| `Hlth` | Healthcare |
| `Money` | Finance |
| `Other` | Other industries |

All return columns are percent daily simple returns. Exact industry definitions
are in `docs/Siccodes12.txt`; the official SIC download link is in the README.
`industry_dictionary.csv` provides the source names and URL. Source trading
dates are retained; weekends and holidays are not filled.

## Financial result NPZ files

The compact archive includes complete main-design files at
`results/financial/main/<industry>.npz` for all 12 industries. Other designs
are recreated at `results/financial/<configuration>/<industry>.npz` by the
full reproduction command. All design-level summary CSVs are included.
For N evaluation dates, T quantiles, and M methods:

| Key | Shape or meaning |
|---|---|
| `dates` | N trading-date strings |
| `origin_index` | Zero-based row index in the prepared return CSV |
| `taus` | T quantile levels: 0.01 and 0.05 |
| `methods` | M method names, in the stored forecast-axis order |
| `primary_methods` | Eight original financial methods |
| `actual_return_percent` | N realized returns in percent units |
| `sigma_percent` | N strictly prior-information EWMA volatility forecasts |
| `forecasts` | N x T x M forecast quantiles in percent units |
| `pinball_loss` | N x T x M realized quantile losses |
| `hits` | N x T x M indicators of returns below forecast quantiles |
| `crossings` | N x M indicators that the lower quantile exceeds the higher one |
| `selected_n` | Shared recent-window length for the 1% selector level |
| `selected_n10` | Shared recent-window length for the 10% selector level |
| `selected_weight`, `selected_lambda` | N x T calibrated borrowing diagnostics |
| `selected_radius_percent` | N x T samplewise adjustment bounds |
| `quantile_grid_percent` | N x K x T recent-candidate quantiles |

Additional keys retain fixed-window weights, plug-in weights, CV choices,
selector critical values, and related component diagnostics. Load all keys with
`numpy.load(path, allow_pickle=False)` and inspect `files` for their exact names.
Adjacent JSON files retain configuration, seed protocol, origin count, timing,
and the NPZ hash.

`results/financial/main_predictions.csv.gz` is a generated long-format daily
export; it is omitted from the compact archive because it duplicates values in
the included main-design NPZ files. A full rerun regenerates it.
Blank borrowing weights mean not applicable or unavailable; they do not mean
zero. `score_selected_n` records the shared 1% selector diagnostic, not a
method-specific estimation-window length. Method-specific diagnostics remain
in the NPZ files.

## Simulation result NPZ files

Full reruns generate files at
`results/simulation/<family>/<scenario>_phi<phi>_n<n>.npz`. The compact archive
retains complete summary CSVs and three small validation subsets at
`results/reference/simulation/`, rather than all replication arrays.

| Key | Shape or meaning |
|---|---|
| `estimates` | R x T x M estimates for every replication, quantile, and method |
| `truth` | T true endpoint marginal quantiles |
| `taus`, `methods`, `grid` | Quantile, method, and candidate-window definitions |
| `quantile_grid` | R x K x T candidate recent-window quantiles |
| `selected_n`, `selected_n10` | R selected recent-window lengths |
| `adaptive_weight`, `adaptive_lambda` | R x T borrowing diagnostics |
| `fixed_weight` | R x T fixed-window borrowing weights |
| `adjustment_radius` | R x T samplewise adjustment bounds |
| `beta_proxy` | R x T recent-bias calibration proxy |
| `cv_n`, `cv_one_se_n`, `lepski_n` | R x T component window choices |

R is 1,000 for the core and sensitivity designs and 10,000 for each of the
seven independent precision designs. Simulation observations are generated
data and are distinct from the real financial source observations. To obtain
their historical/recent vectors, use `code/export_simulation_data.py`.
Validation subsets retain the first three replications of three designs;
their adjacent JSON files identify the original files, hashes, and selected
indices. Two financial validation subsets retain positions 0 and 2765 of
the `recent750/Enrgy` and `risk025/NoDur` backtests.

## CSV summaries

`financial_summary.csv` contains all 3,240 configuration-industry-quantile-method
rows. `dm_bh_p_original8` uses the original eight-method family; `dm_bh_p` uses
the extended 15-method family. `financial_ablation.csv` has its separate paired
comparison family. All configurations are retained.

`simulation_summary.csv` and `precision_simulation_summary.csv` contain all
method-level MSEs, bias, Monte Carlo standard errors, and pointwise intervals.
The corresponding `*_ablation.csv` files hold borrowing comparisons against
the identical recent-window selector. Percentage-gain columns use literal
percent units; 5.70 means 5.70%, not 570%.
