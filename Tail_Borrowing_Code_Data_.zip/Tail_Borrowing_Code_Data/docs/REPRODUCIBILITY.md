# Reproducibility conventions

## Frozen settings

`experiment_manifest.json` defines the 12 industry series, all nine financial
designs, the original and extended method families, and 104 simulation cells.
`precision_manifest.json` defines seven independently seeded precision cells.
Their `simulation` sections record the complete cell list and resampling counts.

The principal settings are recent-window length 250, historical length 3n,
gap 30, circular-bootstrap block length 10, risk budget 0.05, 199 quantile
bootstrap draws, 999 selector multiplier draws, and quantiles 0.01 and 0.05.
The two tails share the recent-window choice but have separate borrowing
calibrations. Exact alternatives are defined in the manifests.

## Random streams

Financial streams use `SeedSequence([config.seed, full_csv_industry_index,
raw_origin_index])`. Industry indices refer to the complete source-column
order even when a single industry is recomputed.

Expanded simulations use `SeedSequence([seed, n_recent, round(1000*phi),
SCENARIOS_EXT.index(scenario), replication])`. Replication indices begin at
zero. The data stream and the selector and resampling streams are independently
spawned. The export script recreates the original first spawned data stream.

The main financial seed is 2026101206, the repeat seed is 2026101207, the
expanded simulation seed is 2026101210, and the independent precision seed is
2026101216. The precision cells were selected after the initial diagnostic
check and are recorded explicitly in `precision_manifest.json`.

## Statistical conventions

Sample quantiles use the linearly interpolated type-7 definition. The
financial pipeline has a zero conditional mean and a common causal EWMA
volatility filter. Forecasts at an origin use prior observations only.
Loss is pinball loss in percent-return units. The exact coverage, loss-test,
HAC-lag, and BH-family conventions are recorded in the manifest and source.
Quantile crossings are retained and reported.

Monte Carlo comparisons use the same simulated path for all methods.
Borrowing increments compare with the identical selected-window estimator.
The separate simulation and financial method orders should always be read
from their stored `methods` arrays. Financial observations use a fixed
download vintage and are not a point-in-time release history.

## Validation scope

The full source package was validated before compaction; its historical audit
is preserved in `release_validation.json`. The compact release validates all
retained main financial arrays against their hashes, prepared observations,
and summary values, checks complete design coverage in the summary CSVs,
and checks the retained validation subsets. Representative
numerical examples are also recomputed at the complete frozen resampling
counts. `release_validation.json` reports what was checked and distinguishes
stored-output reconciliation from example recomputation. Full experiment
generation is available through `reproduce.py --stage all`.

Model source files named by the pre-run hash manifests are unchanged from the
recorded experiment runs. The driver and data-preparation files provide
portable entry points. Plotting has a portable serif-font fallback and English
metadata captions; it does not change statistical computations. The reference
main-design financial NPZ arrays, prepared financial observations, all summary
tables, and all figures are retained. Secondary financial arrays, complete
simulation replication arrays, and the duplicate daily CSV export are omitted
to keep the archive below 20,000,000 bytes; the complete model code, settings,
and seeds regenerate them. `--stage summarize` recreates figures and overview
tables from the retained tables and main arrays. `--stage all` recomputes every
experiment and summary, using the full stored-output verifier after generation.
Original provider downloads are omitted. All reproduction stages use the
bundled frozen prepared CSV by default and need no network access. To rebuild
from a source ZIP, use `--input-zip`; `--download-raw` fetches the live official
ZIP. Both source-archive routes require the original CRSP vintage 202608 and
its stored hashes, preventing revised observations from being mixed with the
reference experiment outputs. Download links are listed in the README.

ZIP/NPZ/gzip container bytes can differ when files are regenerated because of
timestamps and packaging. Numerical comparisons use arrays and table values.
Within the checked software environment, example arrays are compared with
absolute and relative tolerances of 1e-12. The release checksum file identifies
the exact archived bytes, including the unchanged prepared sample and outputs.
